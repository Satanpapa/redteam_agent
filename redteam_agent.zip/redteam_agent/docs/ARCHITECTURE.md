# Red Team Agent Architecture
## Полностью локальный автономный адаптивный Red Team Agent

---

## 1. Архитектурная диаграмма

```mermaid
flowchart TB
    subgraph User_Layer["User Layer"]
        CLI[CLI Interface]
        Config[Configuration]
    end

    subgraph Orchestration_Layer["Orchestration Layer (LangGraph)"]
        direction TB
        StateGraph[StateGraph + Checkpointing]
        
        subgraph Nodes["State Nodes"]
            Planner[Planner Agent]
            Decision[Decision Engine]
            Executor[Executor Agent]
            Analyzer[Analyzer Agent]
            Learner[Learning Agent]
        end
        
        subgraph Edges["Conditional Edges"]
            E1[plan → decide]
            E2[decide → execute]
            E3[execute → analyze]
            E4[analyze → learn]
            E5[learn → plan]
            E6[should_continue?]
        end
    end

    subgraph Intelligence_Layer["Intelligence Layer"]
        direction TB
        WorldModel[World Model<br/>Graph Database]
        Memory[(Memory System)]
        VectorStore[(Vector Store<br/>Chroma/LanceDB)]
    end

    subgraph Execution_Layer["Execution Layer"]
        direction TB
        DockerSandbox[Docker Sandbox<br/>Kali Linux]
        SandboxMgr[Sandbox Manager<br/>Lifecycle + Snapshots]
        
        subgraph Tools["Tool Layer"]
            Nmap[Nmap Normalizer]
            Gobuster[Gobuster Normalizer]
            SQLMap[SQLMap Normalizer]
            Metasploit[Metasploit RPC]
            Nuclei[Nuclei Normalizer]
            Custom[Custom Tools]
        end
    end

    subgraph Data_Layer["Data Layer"]
        SQLite[(SQLite<br/>Structured Data)]
        CVE_DB[Local CVE DB]
        ExploitDB[Exploit-DB Local]
    end

    CLI --> StateGraph
    Config --> StateGraph
    
    StateGraph --> Planner
    Planner --> Decision
    Decision --> Executor
    Executor --> Analyzer
    Analyzer --> Learner
    Learner --> E6
    E6 -->|continue| Planner
    E6 -->|finish| CLI
    
    Planner -.->|query/update| WorldModel
    Decision -.->|query| WorldModel
    Analyzer -.->|update| WorldModel
    Learner -.->|store patterns| VectorStore
    
    Executor -.->|spawn| DockerSandbox
    SandboxMgr -.->|manage| DockerSandbox
    
    Executor --> Tools
    Tools -.->|parse/enrich| SQLite
    Tools -.->|CVE lookup| CVE_DB
    Tools -.->|exploit lookup| ExploitDB
    
    Analyzer -.->|store| Memory
    Planner -.->|retrieve| Memory
    
    WorldModel -.->|persist| SQLite
```

---

## 2. Компоненты системы

### 2.1 Orchestrator (LangGraph StateGraph)

**Назначение**: Центральный оркестратор управляет жизненным циклом атаки через состояния и условные переходы.

**Ключевые особенности**:
- **Checkpointing**: Возможность восстановления после сбоя
- **Conditional Edges**: Динамическое принятие решений о следующем шаге
- **State Persistence**: Сохранение состояния между итерациями
- **Parallel Execution**: Возможность параллельного выполнения независимых задач

### 2.2 Planner Agent

**Назначение**: Стратегическое планирование на основе текущего World Model и целей.

**Входы**:
- Текущее состояние World Model
- История предыдущих действий
- Цели атаки (scope, targets)
- Память об успешных/неуспешных тактиках

**Выходы**:
- Список возможных действий с приоритетами
- Гипотезы об уязвимостях
- Стратегия атаки

**Алгоритм**:
1. Анализ текущего состояния графа знаний
2. Генерация гипотез на основе LLM
3. Оценка покрытия (coverage analysis)
4. Формирование плана действий

### 2.3 Decision Engine (Сердце системы)

**Назначение**: Оценка и ранжирование возможных действий по 4-мерной метрике.

**Метрики (MCDA)**:

| Метрика | Диапазон | Описание |
|---------|----------|----------|
| Probability of Success | 0.0 - 1.0 | Вероятность успеха на основе истории и контекста |
| Impact / Value | 0 - 10 | Потенциальная ценность результата |
| Cost | time + resources | Временные и ресурсные затраты |
| Risk | detection + stability | Риск обнаружения и нестабильности |

**Scoring Function**:
```python
score = (prob_success * impact) / (cost * (1 + risk))
```

**Monte Carlo Simulation** (опционально):
- N итераций с случайными вариациями параметров
- Выбор действия с наилучшим ожидаемым результатом

### 2.4 Executor Agent

**Назначение**: Безопасное выполнение инструментов в Docker sandbox.

**Процесс**:
1. Получение команды от Decision Engine
2. Подготовка sandbox (snapshot/restore)
3. Выполнение через Sandbox Manager
4. Получение структурированного вывода
5. Передача результатов Analyzer

**Безопасность**:
- Только Docker-контейнер, никаких host-команд
- Resource limits (CPU, memory, network)
- Network isolation
- Volume mounting control

### 2.5 Analyzer Agent

**Назначение**: Анализ результатов, обновление World Model, извлечение уроков.

**Задачи**:
1. Парсинг вывода инструментов в Pydantic модели
2. Корреляция с существующими данными
3. Обновление World Model (новые хосты, порты, уязвимости)
4. Оценка успешности действия
5. Генерация обратной связи для Learning Agent

### 2.6 Learning Agent

**Назначение**: Долгосрочное обучение и адаптация.

**Функции**:
- Сохранение успешных паттернов в Vector Store
- Обновление оценок эффективности тактик
- Обнаружение новых техник из результатов
- Адаптация scoring weights на основе истории

---

## 3. World Model (Граф знаний)

### 3.1 Структура данных

```
Hosts
├── Network (subnet, routes)
├── Ports
│   ├── Services
│   │   ├── Versions
│   │   ├── Configurations
│   │   └── Vulnerabilities
│   │       ├── CVEs
│   │       ├── Exploits
│   │       └── Post-Exploitation Paths
```

### 3.2 Реализация

**Storage**: SQLite + NetworkX (или Neo4j Community в Docker)

**Сущности**:
- `Host`: IP, hostname, OS, status
- `Port`: number, protocol, state
- `Service`: name, version, banner
- `Vulnerability`: CVE, severity, description
- `Exploit`: name, type, success_rate
- `Credential`: username, password, hash, source

**Отношения**:
- `HAS_PORT`: Host → Port
- `RUNS_SERVICE`: Port → Service
- `HAS_VULNERABILITY`: Service → Vulnerability
- `EXPLOITED_BY`: Vulnerability → Exploit
- `LEADS_TO`: Exploit → PostExploit

---

## 4. Memory Architecture

### 4.1 Short-term Memory

- **LangGraph State**: Текущее состояние выполнения
- **World Model Snapshot**: Текущее состояние графа знаний
- **Context Window**: Последние N действий для LLM

### 4.2 Long-term Memory

**Vector Store (Chroma/LanceDB)**:
- Успешные тактики и паттерны
- Эффективные эксплойты для конкретных сервисов
- Полезные нагрузки и техники обхода

**SQLite (Tactics Table)**:
```sql
CREATE TABLE tactics (
    id INTEGER PRIMARY KEY,
    pattern TEXT,
    context_hash TEXT,
    success_rate REAL,
    avg_execution_time REAL,
    last_used TIMESTAMP,
    use_count INTEGER
);
```

---

## 5. Tool Layer

### 5.1 Принципы

Каждый инструмент:
1. Парсит вывод в структурированные Pydantic-модели
2. Обогащает данные (CVE search, exploit-db lookup)
3. Коррелирует с World Model
4. НЕ использует простой regex-парсинг

### 5.2 Поддерживаемые инструменты

- **nmap**: Порт-сканирование, OS detection, service detection
- **gobuster/ffuf**: Directory bruteforce, virtual hosts
- **sqlmap**: SQL injection detection and exploitation
- **metasploit**: Full exploit framework via RPC
- **nuclei**: Vulnerability scanning with templates
- **hydra**: Credential bruteforce
- **ldapsearch**: Active Directory enumeration
- **bloodhound**: AD attack path analysis

---

## 6. Docker Sandbox Manager

### 6.1 Функции

- **Lifecycle Management**: create, start, stop, remove
- **Resource Limits**: CPU, memory, network bandwidth
- **Snapshot/Restore**: Сохранение и восстановление состояния
- **Volume Management**: Монтирование необходимых директорий
- **Network Isolation**: Контроль исходящих соединений

### 6.2 Конфигурация

```yaml
sandbox:
  image: kalilinux/kali-rolling:latest
  resources:
    cpus: 2.0
    memory: 4g
    network: isolated  # или bridge для доступа к target
  volumes:
    - ./tools:/opt/tools:ro
    - ./workspace:/workspace:rw
  capabilities:
    - NET_ADMIN
    - SYS_PTRACE
```

---

## 7. Execution Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                         START                                   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  1. INITIALIZATION                                              │
│     • Load configuration                                        │
│     • Initialize World Model                                    │
│     • Setup Docker Sandbox                                      │
│     • Connect to Ollama                                         │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  2. PLANNER AGENT                                               │
│     • Analyze current World Model                               │
│     • Query long-term memory for similar contexts               │
│     • Generate candidate actions                                │
│     • Output: List[Action] with initial scores                │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  3. DECISION ENGINE                                             │
│     • For each candidate action:                                │
│       - Calculate 4D metric                                     │
│       - Apply Monte Carlo (optional)                          │
│     • Select action with highest score                        │
│     • Output: Selected Action                                   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  4. EXECUTOR AGENT                                              │
│     • Prepare sandbox (snapshot/restore)                      │
│     • Execute tool in Docker                                    │
│     • Capture structured output                                 │
│     • Output: ExecutionResult                                   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  5. ANALYZER AGENT                                              │
│     • Parse output to Pydantic models                           │
│     • Enrich with CVE/Exploit data                              │
│     • Update World Model                                        │
│     • Evaluate success/failure                                  │
│     • Output: AnalysisResult                                    │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  6. LEARNING AGENT                                              │
│     • Store successful pattern in Vector Store                │
│     • Update tactic effectiveness scores                      │
│     • Adjust Decision Engine weights (optional)               │
│     • Output: LearningUpdate                                    │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  7. CONTINUE?                                                   │
│     • Check termination conditions:                           │
│       - Goal achieved?                                          │
│       - Max iterations reached?                               │
│       - No more viable actions?                               │
│     • YES → Go to step 2 (Planner)                            │
│     • NO  → Generate Report                                     │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                         END                                     │
│     • Generate final report                                     │
│     • Export World Model                                        │
│     • Cleanup resources                                         │
└─────────────────────────────────────────────────────────────────┘
```

---

## 8. Технологический стек

| Компонент | Технология |
|-----------|------------|
| Language | Python 3.11+ |
| Orchestration | LangGraph (StateGraph) |
| LLM | Ollama (qwen2.5-coder:32b / deepseek-coder-v2) |
| Data Models | Pydantic v2 |
| Database | SQLite + NetworkX |
| Vector Store | ChromaDB или LanceDB |
| Sandbox | Docker + Kali Linux |
| Observability | Structured Logging + OpenTelemetry |

---

## 9. Преимущества над Decepticon

1. **Полностью локальный**: Работает offline без внешних API
2. **Адаптивный Decision Engine**: MCDA + Monte Carlo вместо жёстких правил
3. **World Model**: Полноценный граф знаний вместо плоских структур
4. **Умный Tool Layer**: Структурированный вывод + обогащение данных
5. **Двухуровневая память**: Краткосрочная + долгосрочная с Vector Store
6. **Замкнутый цикл обучения**: Каждая итерация улучшает будущие решения
7. **Production-ready**: Type hints, Pydantic v2, comprehensive logging
