# Пример сценария атаки: Metasploitable 3

## Обзор цели

**Metasploitable 3** — это уязвимая виртуальная машина, созданная Rapid7 для тестирования Metasploit. Она содержит множество уязвимостей различной сложности.

### Конфигурация цели
- **IP**: 192.168.56.101 (пример)
- **OS**: Windows Server 2008 R2 / Ubuntu 14.04 (два варианта)
- **Сложность**: Средняя-Высокая

---

## Сценарий 1: Полный цикл атаки (Windows версия)

### Итерация 1: Разведка (Reconnaissance)

**Состояние агента:**
```python
AgentState(
    target_scope=["192.168.56.101/24"],
    current_phase=Phase.RECONNAISSANCE,
    iteration=0
)
```

**Planner генерирует действия:**
1. `nmap -sn 192.168.56.0/24` - Host discovery
2. `nmap -sV -sC 192.168.56.101` - Service detection

**Decision Engine оценивает:**
| Действие | Prob | Impact | Cost | Risk | Score |
|----------|------|--------|------|------|-------|
| Host discovery | 0.95 | 5 | 2 | 1 | **0.79** |
| Service scan | 0.90 | 7 | 5 | 2 | **0.51** |

**Выбрано:** Host discovery (nmap -sn)

**Результат выполнения:**
```
Nmap scan report for 192.168.56.101
Host is up (0.00032s latency).
```

**World Model обновляется:**
```python
Host(
    ip="192.168.56.101",
    status=HostStatus.UP,
    discovered_at=datetime.utcnow()
)
```

---

### Итерация 2: Сканирование портов

**Planner видит:** Host обнаружен, но порты не просканированы

**Генерирует:**
1. `nmap -sV -sC -O 192.168.56.101` - Полное сканирование
2. `nmap --top-ports 100 192.168.56.101` - Быстрое сканирование

**Decision Engine:**
| Действие | Prob | Impact | Cost | Risk | Score |
|----------|------|--------|------|------|-------|
| Full scan | 0.95 | 9 | 8 | 2 | **0.43** |
| Top 100 | 0.95 | 7 | 4 | 2 | **0.66** |

**Выбрано:** Top 100 ports (быстрее, меньше риск детекции)

**Результат:**
```
PORT      STATE SERVICE      VERSION
80/tcp    open  http         Apache httpd 2.4.23
3306/tcp  open  mysql        MySQL 5.5.52
8080/tcp  open  http         Apache Tomcat/Coyote JSP engine 1.1
4848/tcp  open  ssl/http     GlassFish Server Open Source Edition 4.1
8585/tcp  open  http         Apache httpd 2.4.23
9200/tcp  open  http         Elasticsearch 1.1.1
```

**World Model:**
```python
# Добавлены порты
ports = [
    Port(number=80, protocol=TCP, state=OPEN, service_name="http"),
    Port(number=3306, protocol=TCP, state=OPEN, service_name="mysql"),
    Port(number=8080, protocol=TCP, state=OPEN, service_name="http"),
    Port(number=9200, protocol=TCP, state=OPEN, service_name="elasticsearch"),
]

# Сервисы с версиями
services = [
    Service(name="http", product="Apache", version="2.4.23"),
    Service(name="mysql", product="MySQL", version="5.5.52"),
    Service(name="elasticsearch", product="Elasticsearch", version="1.1.1"),
]
```

---

### Итерация 3: Переход к эксплуатации

**Analyzer обнаруживает:** Elasticsearch 1.1.1 имеет известные уязвимости

**Learning Agent находит в памяти:** Успешный эксплойт CVE-2014-3120 для Elasticsearch < 1.2

**Planner генерирует:**
1. Поиск директорий на 80/tcp
2. Эксплуатация Elasticsearch
3. Проверка дефолтных creds для MySQL

**Decision Engine оценивает:**
| Действие | Prob | Impact | Cost | Risk | Score |
|----------|------|--------|------|------|-------|
| Gobuster 80 | 0.70 | 5 | 3 | 1 | **0.58** |
| ES exploit | 0.60 | 9 | 4 | 3 | **0.45** |
| MySQL creds | 0.30 | 8 | 2 | 2 | **0.48** |

**Выбрано:** Gobuster (меньше риск, хороший фундамент)

**Результат:**
```
/.htaccess            (Status: 403)
/.htpasswd            (Status: 403)
/phpmyadmin           (Status: 200)
/wp-admin             (Status: 302)
```

**World Model обновляется:**
- Найден phpMyAdmin → потенциальная админ-панель
- Найден WordPress → возможность WP-эксплойтов

---

### Итерация 4: Эксплуатация Elasticsearch

**Planner видит:** phpMyAdmin требует авторизации, WordPress требует перебора

**Генерирует:**
1. Эксплуатация CVE-2014-3120 (Elasticsearch RCE)
2. WPScan для перечисления пользователей

**Decision Engine:**
| Действие | Prob | Impact | Cost | Risk | Score |
|----------|------|--------|------|------|-------|
| ES RCE | 0.55 | 10 | 5 | 4 | **0.42** |
| WPScan | 0.75 | 6 | 4 | 2 | **0.56** |

**Выбрано:** WPScan (более консервативно)

**Результат:**
```
[i] User(s) Identified:
[+] admin
[+] editor
```

---

### Итерация 5: RCE через Elasticsearch

**Planner видит:** У нас есть пользователи WP, но нужны пароли

**Learning Agent:** Прошлые попытки брутфорса имели низкий success rate

**Decision Engine пересчитывает веса:** probability ↓, impact ↑

**Выбрано:** Elasticsearch RCE (CVE-2014-3120)

**Результат:**
```python
ExecutionResult(
    success=True,
    new_vulnerabilities=[
        Vulnerability(
            cve_id="CVE-2014-3120",
            name="Elasticsearch Remote Code Execution",
            severity=VulnerabilitySeverity.CRITICAL,
        )
    ]
)
```

**Получен shell:**
```
uid=1000(vagrant) gid=1000(vagrant) groups=1000(vagrant)
```

**World Model:**
```python
Host(
    ip="192.168.56.101",
    compromised=True,
    compromise_method="CVE-2014-3120",
    access_level="user",
)
```

---

### Итерация 6: Post-Exploitation

**Planner видит:** У нас есть shell, но нужен root/admin

**Генерирует:**
1. Перечисление SUID бинарников
2. Поиск kernel exploits
3. Перечисление cron jobs

**Decision Engine:**
| Действие | Prob | Impact | Cost | Risk | Score |
|----------|------|--------|------|------|-------|
| SUID enum | 0.80 | 7 | 2 | 1 | **0.93** |
| Kernel exp | 0.40 | 10 | 6 | 5 | **0.24** |
| Cron enum | 0.70 | 5 | 2 | 1 | **0.82** |

**Выбрано:** SUID enumeration

**Результат:**
```
-rwsr-xr-x 1 root root 44320 Mar  1  2021 /usr/bin/nmap
```

**Learning Agent:** Находит в памяти: nmap SUID → privilege escalation

---

### Итерация 7: Privilege Escalation

**Planner генерирует:**
```bash
nmap --interactive
nmap> !sh
```

**Результат:**
```
uid=0(root) gid=0(root) groups=0(root)
```

**World Model:**
```python
Host(
    ip="192.168.56.101",
    compromised=True,
    access_level="root",
)
```

---

## Сводка атаки

### Timeline
```
T+0:00   Host discovery
T+0:05   Port scanning (6 services)
T+0:10   Directory enumeration (phpMyAdmin, WordPress)
T+0:15   WordPress enumeration (users: admin, editor)
T+0:20   Elasticsearch RCE → user shell
T+0:25   SUID enumeration (nmap)
T+0:30   Privilege escalation → root
```

### Обнаруженные сущности
| Тип | Количество |
|-----|------------|
| Hosts | 1 |
| Open Ports | 6 |
| Services | 6 |
| Vulnerabilities | 3 (1 Critical) |
| Credentials | 0 (не потребовались) |

### Attack Path
```
[Recon] → [Port Scan] → [Web Enum] → [WP Enum] → [ES Exploit] → [SUID Enum] → [PrivEsc]
```

---

## Сценарий 2: Адаптивное поведение

### Ситуация: Elasticsearch неуязвим (пропатчен)

**Итерация 4 (альтернативная):**

**Execution Result:**
```python
ExecutionResult(
    success=False,
    error_message="Exploit failed: target not vulnerable"
)
```

**Analyzer:** Обновляет success rate для CVE-2014-3120 → 0%

**Learning Agent:**
- Снижает оценку ES-эксплойтов
- Повышает вес для credential attacks

**Decision Engine пересчитывает веса:**
```python
weights = {
    "probability": 0.30,  # ↑
    "impact": 0.20,
    "cost": 0.20,
    "risk": 0.20,         # ↑
    "novelty": 0.05,
    "stealth": 0.05,
}
```

**Planner генерирует новую стратегию:**
1. Hydra против phpMyAdmin
2. WP bruteforce
3. MySQL default creds

**Результат:** Успешный вход в phpMyAdmin с admin:admin

**Путь к root:** phpMyAdmin → SQL injection → file write → web shell → privilege escalation

---

## Ключевые преимущества системы

### 1. Адаптивность
- При неудаче ES-эксплойта → автоматический переход к credential attacks
- Decision Engine пересчитывает веса на основе истории

### 2. Обучение
- Успешный SUID→root путь сохраняется в памяти
- При следующей атаке на похожую систему → SUID enum получает higher priority

### 3. Структурированные данные
- Все открытые порты, сервисы, уязвимости в World Model
- Можно строить attack paths через граф

### 4. Безопасность
- Все инструменты выполняются в Docker sandbox
- Нет прямого доступа к host-системе
