"""
Decision Engine - Multi-Criteria Decision Analysis (MCDA) for Red Team Agent
Implements intelligent action selection using weighted scoring and Monte Carlo simulation
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np

from models import Action, ActionStatus, TacticPattern


@dataclass
class DecisionCriteria:
    """Individual criteria for MCDA"""
    name: str
    weight: float  # 0.0 to 1.0
    value: float   # Normalized 0.0 to 1.0
    higher_is_better: bool = True
    
    def normalized_score(self) -> float:
        """Get normalized score based on direction"""
        if self.higher_is_better:
            return self.value * self.weight
        else:
            return (1.0 - self.value) * self.weight


@dataclass
class ActionMetrics:
    """4-dimensional metrics for action evaluation"""
    probability_success: float = 0.5  # 0.0 - 1.0
    impact: float = 5.0               # 0.0 - 10.0
    cost: float = 5.0                 # 0.0 - 10.0 (lower is better)
    risk: float = 5.0                 # 0.0 - 10.0 (lower is better)
    
    # Additional contextual metrics
    novelty: float = 0.5              # How new/unexpected is this approach
    stealth: float = 0.5              # 0.0 - 1.0, higher is stealthier
    
    def validate(self) -> None:
        """Validate all metrics are in valid ranges"""
        assert 0.0 <= self.probability_success <= 1.0, "probability_success must be in [0, 1]"
        assert 0.0 <= self.impact <= 10.0, "impact must be in [0, 10]"
        assert 0.0 <= self.cost <= 10.0, "cost must be in [0, 10]"
        assert 0.0 <= self.risk <= 10.0, "risk must be in [0, 10]"
        assert 0.0 <= self.novelty <= 1.0, "novelty must be in [0, 1]"
        assert 0.0 <= self.stealth <= 1.0, "stealth must be in [0, 1]"


class DecisionEngine:
    """
    Multi-Criteria Decision Analysis engine for selecting optimal actions
    
    Uses weighted scoring with optional Monte Carlo simulation for uncertainty handling
    """
    
    def __init__(
        self,
        weights: Optional[Dict[str, float]] = None,
        enable_monte_carlo: bool = True,
        mc_iterations: int = 100,
        random_seed: Optional[int] = None
    ):
        """
        Initialize Decision Engine
        
        Args:
            weights: Custom weights for criteria (probability, impact, cost, risk, novelty, stealth)
            enable_monte_carlo: Whether to use Monte Carlo simulation
            mc_iterations: Number of Monte Carlo iterations
            random_seed: Random seed for reproducibility
        """
        # Default weights - can be adjusted based on engagement goals
        self.weights = weights or {
            "probability": 0.25,
            "impact": 0.25,
            "cost": 0.20,      # Lower cost is better
            "risk": 0.15,      # Lower risk is better
            "novelty": 0.10,
            "stealth": 0.05,
        }
        
        # Validate weights sum to 1.0
        total = sum(self.weights.values())
        if not 0.99 <= total <= 1.01:
            raise ValueError(f"Weights must sum to 1.0, got {total}")
        
        self.enable_monte_carlo = enable_monte_carlo
        self.mc_iterations = mc_iterations
        
        if random_seed:
            random.seed(random_seed)
            np.random.seed(random_seed)
        
        # Historical performance tracking
        self.tactic_history: Dict[str, TacticPattern] = {}
        
        # Adaptive weight adjustment
        self.success_history: List[bool] = []
        self.adaptive_weights_enabled = True
    
    def calculate_score(self, metrics: ActionMetrics) -> float:
        """
        Calculate weighted score for an action
        
        Formula combines all criteria with their weights:
        score = (prob * impact * novelty * stealth) / (cost * risk)
        
        Args:
            metrics: ActionMetrics instance
            
        Returns:
            Final weighted score (higher is better)
        """
        metrics.validate()
        
        # Normalize all metrics to 0-1 range
        norm_impact = metrics.impact / 10.0
        norm_cost = 1.0 - (metrics.cost / 10.0)  # Invert: lower cost is better
        norm_risk = 1.0 - (metrics.risk / 10.0)  # Invert: lower risk is better
        
        # Calculate weighted components
        score = (
            metrics.probability_success * self.weights["probability"] +
            norm_impact * self.weights["impact"] +
            norm_cost * self.weights["cost"] +
            norm_risk * self.weights["risk"] +
            metrics.novelty * self.weights["novelty"] +
            metrics.stealth * self.weights["stealth"]
        )
        
        return score
    
    def monte_carlo_score(
        self,
        metrics: ActionMetrics,
        uncertainty: Optional[Dict[str, float]] = None
    ) -> Tuple[float, float]:
        """
        Run Monte Carlo simulation to estimate score distribution
        
        Args:
            metrics: Base metrics
            uncertainty: Standard deviation for each metric (default: 10% of value)
            
        Returns:
            Tuple of (mean_score, std_deviation)
        """
        if uncertainty is None:
            uncertainty = {
                "probability": 0.1,
                "impact": 0.5,
                "cost": 0.5,
                "risk": 0.5,
                "novelty": 0.1,
                "stealth": 0.1,
            }
        
        scores = []
        
        for _ in range(self.mc_iterations):
            # Sample from normal distribution around each metric
            sampled = ActionMetrics(
                probability_success=np.clip(
                    np.random.normal(metrics.probability_success, uncertainty["probability"]),
                    0.0, 1.0
                ),
                impact=np.clip(
                    np.random.normal(metrics.impact, uncertainty["impact"]),
                    0.0, 10.0
                ),
                cost=np.clip(
                    np.random.normal(metrics.cost, uncertainty["cost"]),
                    0.0, 10.0
                ),
                risk=np.clip(
                    np.random.normal(metrics.risk, uncertainty["risk"]),
                    0.0, 10.0
                ),
                novelty=np.clip(
                    np.random.normal(metrics.novelty, uncertainty["novelty"]),
                    0.0, 1.0
                ),
                stealth=np.clip(
                    np.random.normal(metrics.stealth, uncertainty["stealth"]),
                    0.0, 1.0
                ),
            )
            
            scores.append(self.calculate_score(sampled))
        
        return float(np.mean(scores)), float(np.std(scores))
    
    def evaluate_action(
        self,
        action: Action,
        context: Optional[Dict] = None,
        use_historical: bool = True
    ) -> Dict:
        """
        Evaluate a single action and return detailed results
        
        Args:
            action: Action to evaluate
            context: Additional context for evaluation
            use_historical: Whether to incorporate historical performance
            
        Returns:
            Dictionary with evaluation results
        """
        # Build metrics from action
        metrics = ActionMetrics(
            probability_success=action.probability_success,
            impact=action.impact_score,
            cost=action.cost_score,
            risk=action.risk_score,
        )
        
        # Adjust based on historical performance if available
        if use_historical and action.tool_name in self.tactic_history:
            pattern = self.tactic_history[action.tool_name]
            if pattern.total_attempts > 0:
                # Blend historical success rate with estimated probability
                historical_rate = pattern.success_rate
                metrics.probability_success = (
                    0.7 * metrics.probability_success +
                    0.3 * historical_rate
                )
                
                # Adjust cost based on average execution time
                if pattern.avg_execution_time:
                    time_cost = min(pattern.avg_execution_time / 60.0, 10.0)
                    metrics.cost = 0.7 * metrics.cost + 0.3 * time_cost
        
        # Calculate base score
        base_score = self.calculate_score(metrics)
        
        result = {
            "action_id": action.id,
            "action_name": action.name,
            "base_score": base_score,
            "metrics": metrics,
        }
        
        # Run Monte Carlo if enabled
        if self.enable_monte_carlo:
            mc_mean, mc_std = self.monte_carlo_score(metrics)
            result["monte_carlo_mean"] = mc_mean
            result["monte_carlo_std"] = mc_std
            result["monte_carlo_confidence_interval"] = (
                mc_mean - 1.96 * mc_std,
                mc_mean + 1.96 * mc_std
            )
            # Use MC mean as final score
            result["final_score"] = mc_mean
        else:
            result["final_score"] = base_score
        
        return result
    
    def select_best_action(
        self,
        actions: List[Action],
        context: Optional[Dict] = None,
        top_k: int = 3
    ) -> Tuple[Action, List[Dict]]:
        """
        Select the best action from a list of candidates
        
        Args:
            actions: List of candidate actions
            context: Additional context
            top_k: Number of top candidates to return in rankings
            
        Returns:
            Tuple of (best_action, all_rankings)
        """
        if not actions:
            raise ValueError("No actions provided")
        
        # Evaluate all actions
        evaluations = []
        for action in actions:
            # Skip already executed actions
            if action.status != ActionStatus.PENDING:
                continue
            
            eval_result = self.evaluate_action(action, context)
            evaluations.append(eval_result)
        
        if not evaluations:
            raise ValueError("No pending actions to evaluate")
        
        # Sort by final score (descending)
        evaluations.sort(key=lambda x: x["final_score"], reverse=True)
        
        # Get best action
        best_action_id = evaluations[0]["action_id"]
        best_action = next(a for a in actions if a.id == best_action_id)
        
        # Update action scores
        for eval_result in evaluations:
            action = next(a for a in actions if a.id == eval_result["action_id"])
            action.final_score = eval_result["final_score"]
        
        return best_action, evaluations[:top_k]
    
    def select_actions_batch(
        self,
        actions: List[Action],
        batch_size: int = 3,
        diversity_penalty: float = 0.1
    ) -> List[Action]:
        """
        Select a diverse batch of actions to execute in parallel
        
        Args:
            actions: List of candidate actions
            batch_size: Number of actions to select
            diversity_penalty: Penalty for similar actions
            
        Returns:
            List of selected actions
        """
        if len(actions) <= batch_size:
            return [a for a in actions if a.status == ActionStatus.PENDING]
        
        selected = []
        remaining = [a for a in actions if a.status == ActionStatus.PENDING]
        
        while len(selected) < batch_size and remaining:
            # Re-score remaining actions with diversity penalty
            for action in remaining:
                base_score = action.final_score or self.evaluate_action(action)["final_score"]
                
                # Apply diversity penalty based on similarity to selected
                penalty = 0.0
                for sel in selected:
                    if self._actions_similar(action, sel):
                        penalty += diversity_penalty
                
                action.final_score = max(0.0, base_score - penalty)
            
            # Select best from remaining
            best = max(remaining, key=lambda a: a.final_score)
            selected.append(best)
            remaining.remove(best)
        
        return selected
    
    def _actions_similar(self, a1: Action, a2: Action) -> bool:
        """Check if two actions are similar (same tool/target)"""
        if a1.tool_name == a2.tool_name:
            return True
        if a1.target_host_id == a2.target_host_id:
            if a1.target_port == a2.target_port:
                return True
        return False
    
    def update_weights_from_outcome(
        self,
        action: Action,
        success: bool,
        actual_impact: Optional[float] = None
    ) -> None:
        """
        Adaptively adjust weights based on action outcome
        
        Args:
            action: The executed action
            success: Whether the action succeeded
            actual_impact: Measured impact (if available)
        """
        if not self.adaptive_weights_enabled:
            return
        
        self.success_history.append(success)
        
        # Keep only last 100 outcomes for adaptation
        if len(self.success_history) > 100:
            self.success_history = self.success_history[-100:]
        
        # Adjust weights based on patterns
        recent_success_rate = sum(self.success_history[-20:]) / min(len(self.success_history), 20)
        
        if recent_success_rate < 0.3:
            # Low success rate - prioritize probability and reduce risk
            self.weights["probability"] = min(0.4, self.weights["probability"] * 1.1)
            self.weights["risk"] = max(0.05, self.weights["risk"] * 0.9)
        elif recent_success_rate > 0.7:
            # High success rate - can afford more risk for higher impact
            self.weights["impact"] = min(0.35, self.weights["impact"] * 1.05)
            self.weights["risk"] = min(0.25, self.weights["risk"] * 1.05)
        
        # Re-normalize weights
        total = sum(self.weights.values())
        self.weights = {k: v / total for k, v in self.weights.items()}
    
    def register_tactic_pattern(self, pattern: TacticPattern) -> None:
        """Register a tactic pattern for historical tracking"""
        self.tactic_history[pattern.tool_name] = pattern
    
    def get_confidence_threshold(self, phase: str) -> float:
        """
        Get minimum confidence threshold for a given phase
        
        Args:
            phase: Current attack phase
            
        Returns:
            Minimum score threshold
        """
        thresholds = {
            "reconnaissance": 0.3,  # Lower threshold for recon
            "weaponization": 0.5,
            "delivery": 0.6,
            "exploitation": 0.7,    # Higher threshold for exploits
            "post_exploitation": 0.6,
        }
        return thresholds.get(phase, 0.5)
    
    def should_execute(
        self,
        action: Action,
        phase: str,
        min_confidence: Optional[float] = None
    ) -> bool:
        """
        Determine if an action should be executed based on confidence
        
        Args:
            action: Action to evaluate
            phase: Current attack phase
            min_confidence: Override minimum confidence
            
        Returns:
            Whether action should be executed
        """
        threshold = min_confidence or self.get_confidence_threshold(phase)
        
        if action.final_score is None:
            eval_result = self.evaluate_action(action)
            action.final_score = eval_result["final_score"]
        
        return action.final_score >= threshold


class ParetoFrontierSelector:
    """
    Select actions using Pareto frontier for multi-objective optimization
    """
    
    def __init__(self):
        self.objectives = ["probability_success", "impact", "stealth"]
        self.objective_directions = {
            "probability_success": "max",
            "impact": "max",
            "stealth": "max",
            "cost": "min",
            "risk": "min",
        }
    
    def dominates(
        self,
        action1: ActionMetrics,
        action2: ActionMetrics
    ) -> bool:
        """
        Check if action1 dominates action2 in Pareto sense
        
        Returns True if action1 is better or equal in all objectives
        and strictly better in at least one
        """
        metrics1 = {
            "probability_success": action1.probability_success,
            "impact": action1.impact / 10.0,
            "stealth": action1.stealth,
            "cost": 1.0 - (action1.cost / 10.0),
            "risk": 1.0 - (action1.risk / 10.0),
        }
        
        metrics2 = {
            "probability_success": action2.probability_success,
            "impact": action2.impact / 10.0,
            "stealth": action2.stealth,
            "cost": 1.0 - (action2.cost / 10.0),
            "risk": 1.0 - (action2.risk / 10.0),
        }
        
        better_in_any = False
        
        for obj in self.objectives:
            if metrics1[obj] < metrics2[obj]:
                return False
            if metrics1[obj] > metrics2[obj]:
                better_in_any = True
        
        return better_in_any
    
    def find_pareto_frontier(
        self,
        actions: List[Action]
    ) -> List[Action]:
        """
        Find the Pareto frontier (non-dominated actions)
        
        Args:
            actions: List of actions to evaluate
            
        Returns:
            List of non-dominated actions
        """
        frontier = []
        
        for action in actions:
            metrics = ActionMetrics(
                probability_success=action.probability_success,
                impact=action.impact_score,
                cost=action.cost_score,
                risk=action.risk_score,
            )
            
            dominated = False
            to_remove = []
            
            for i, frontier_action in enumerate(frontier):
                frontier_metrics = ActionMetrics(
                    probability_success=frontier_action.probability_success,
                    impact=frontier_action.impact_score,
                    cost=frontier_action.cost_score,
                    risk=frontier_action.risk_score,
                )
                
                if self.dominates(frontier_metrics, metrics):
                    dominated = True
                    break
                
                if self.dominates(metrics, frontier_metrics):
                    to_remove.append(i)
            
            if not dominated:
                # Remove dominated actions from frontier
                for i in reversed(to_remove):
                    frontier.pop(i)
                frontier.append(action)
        
        return frontier


# Utility functions
def create_decision_engine_from_config(config: Dict) -> DecisionEngine:
    """Factory function to create DecisionEngine from configuration"""
    return DecisionEngine(
        weights=config.get("decision_weights"),
        enable_monte_carlo=config.get("enable_monte_carlo", True),
        mc_iterations=config.get("monte_carlo_iterations", 100),
        random_seed=config.get("random_seed"),
    )


def quick_select(
    actions: List[Action],
    primary_criterion: str = "final_score"
) -> Optional[Action]:
    """
    Quick selection without full MCDA (for simple cases)
    
    Args:
        actions: List of actions
        primary_criterion: Criterion to sort by
        
    Returns:
        Best action or None if list is empty
    """
    if not actions:
        return None
    
    # Filter pending actions
    pending = [a for a in actions if a.status == ActionStatus.PENDING]
    if not pending:
        return None
    
    # Sort by criterion
    if primary_criterion == "final_score":
        return max(pending, key=lambda a: a.final_score or 0)
    elif primary_criterion == "probability":
        return max(pending, key=lambda a: a.probability_success)
    elif primary_criterion == "impact":
        return max(pending, key=lambda a: a.impact_score)
    else:
        return pending[0]


# Example usage and testing
if __name__ == "__main__":
    # Create decision engine
    engine = DecisionEngine(
        enable_monte_carlo=True,
        mc_iterations=100,
        random_seed=42
    )
    
    # Create sample actions
    actions = [
        Action(
            name="nmap_tcp_scan",
            action_type="scan",
            tool_name="nmap",
            tool_command="nmap -sV -sC target",
            phase="reconnaissance",
            probability_success=0.95,
            impact_score=3.0,
            cost_score=2.0,
            risk_score=1.0,
        ),
        Action(
            name="sqlmap_injection_test",
            action_type="exploit",
            tool_name="sqlmap",
            tool_command="sqlmap -u target",
            phase="exploitation",
            probability_success=0.4,
            impact_score=9.0,
            cost_score=5.0,
            risk_score=4.0,
        ),
        Action(
            name="gobuster_directories",
            action_type="enumerate",
            tool_name="gobuster",
            tool_command="gobuster dir -u target -w wordlist",
            phase="reconnaissance",
            probability_success=0.7,
            impact_score=5.0,
            cost_score=3.0,
            risk_score=1.0,
        ),
    ]
    
    # Select best action
    best_action, rankings = engine.select_best_action(actions, top_k=3)
    
    print("=== Decision Engine Test ===")
    print(f"\nBest action: {best_action.name}")
    print(f"Score: {best_action.final_score:.4f}")
    
    print("\n=== Rankings ===")
    for i, rank in enumerate(rankings, 1):
        print(f"{i}. {rank['action_name']}: {rank['final_score']:.4f}")
        if 'monte_carlo_mean' in rank:
            print(f"   MC Mean: {rank['monte_carlo_mean']:.4f} ± {rank['monte_carlo_std']:.4f}")
