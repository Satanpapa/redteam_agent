"""
Tool Layer - Intelligent tool wrappers with structured output parsing
Normalizes output from various security tools into Pydantic models
"""

from __future__ import annotations

import json
import re
import xml.etree.ElementTree as ET
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional, Type, Union

from models import (
    Credential,
    Exploit,
    ExploitStatus,
    ExploitType,
    Host,
    HostStatus,
    Port,
    PortState,
    Service,
    ServiceProtocol,
    ToolOutput,
    Vulnerability,
    VulnerabilitySeverity,
)


# ═══════════════════════════════════════════════════════════════════════════════
# Base Tool Normalizer
# ═══════════════════════════════════════════════════════════════════════════════

class ToolNormalizer(ABC):
    """Abstract base class for tool normalizers"""
    
    tool_name: str
    supported_formats: List[str] = ["json", "xml", "text"]
    
    @abstractmethod
    def parse(self, output: ToolOutput) -> Dict[str, Any]:
        """
        Parse tool output into structured data
        
        Args:
            output: Raw tool output
            
        Returns:
            Dictionary with parsed entities
        """
        pass
    
    @abstractmethod
    def normalize(self, parsed_data: Dict[str, Any]) -> Dict[str, List]:
        """
        Normalize parsed data into standard entity models
        
        Args:
            parsed_data: Data from parse()
            
        Returns:
            Dictionary with lists of entity models
        """
        pass
    
    def process(self, output: ToolOutput) -> Dict[str, List]:
        """Complete processing pipeline"""
        parsed = self.parse(output)
        return self.normalize(parsed)
    
    def _extract_ips(self, text: str) -> List[str]:
        """Extract IP addresses from text"""
        ip_pattern = r'\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b'
        return list(set(re.findall(ip_pattern, text)))
    
    def _extract_ports(self, text: str) -> List[int]:
        """Extract port numbers from text"""
        port_pattern = r'\b(\d{1,5})/(?:tcp|udp)'
        matches = re.findall(port_pattern, text)
        return [int(p) for p in matches if 1 <= int(p) <= 65535]


# ═══════════════════════════════════════════════════════════════════════════════
# Nmap Normalizer
# ═══════════════════════════════════════════════════════════════════════════════

class NmapNormalizer(ToolNormalizer):
    """
    Normalizer for Nmap scan results
    Supports XML output (-oX) and JSON output (with nmap-formatter)
    """
    
    tool_name = "nmap"
    supported_formats = ["xml", "json", "gnmap"]
    
    def parse(self, output: ToolOutput) -> Dict[str, Any]:
        """Parse Nmap output"""
        # Try XML first (most detailed)
        if output.stdout.strip().startswith("<?xml"):
            return self._parse_xml(output.stdout)
        
        # Try JSON
        try:
            return json.loads(output.stdout)
        except json.JSONDecodeError:
            pass
        
        # Fallback to grepable format parsing
        return self._parse_grepable(output.stdout)
    
    def _parse_xml(self, xml_data: str) -> Dict[str, Any]:
        """Parse Nmap XML output"""
        result = {
            "scan_info": {},
            "hosts": []
        }
        
        try:
            root = ET.fromstring(xml_data)
            
            # Scan info
            scan_info = root.find("scaninfo")
            if scan_info is not None:
                result["scan_info"] = {
                    "type": scan_info.get("type"),
                    "protocol": scan_info.get("protocol"),
                    "numservices": scan_info.get("numservices"),
                }
            
            # Parse hosts
            for host_elem in root.findall("host"):
                host_data = self._parse_host_element(host_elem)
                result["hosts"].append(host_data)
                
        except ET.ParseError as e:
            result["parse_error"] = str(e)
        
        return result
    
    def _parse_host_element(self, host_elem: ET.Element) -> Dict[str, Any]:
        """Parse individual host element from Nmap XML"""
        host_data = {
            "status": "unknown",
            "addresses": {},
            "hostnames": [],
            "ports": [],
            "os": {},
        }
        
        # Status
        status_elem = host_elem.find("status")
        if status_elem is not None:
            host_data["status"] = status_elem.get("state", "unknown")
        
        # Addresses
        for addr in host_elem.findall("address"):
            addr_type = addr.get("addrtype", "ipv4")
            host_data["addresses"][addr_type] = {
                "addr": addr.get("addr"),
                "vendor": addr.get("vendor"),
            }
        
        # Hostnames
        hostnames_elem = host_elem.find("hostnames")
        if hostnames_elem is not None:
            for hostname in hostnames_elem.findall("hostname"):
                host_data["hostnames"].append({
                    "name": hostname.get("name"),
                    "type": hostname.get("type"),
                })
        
        # Ports
        ports_elem = host_elem.find("ports")
        if ports_elem is not None:
            for port in ports_elem.findall("port"):
                port_data = self._parse_port_element(port)
                host_data["ports"].append(port_data)
        
        # OS detection
        os_elem = host_elem.find("os")
        if os_elem is not None:
            osmatch = os_elem.find("osmatch")
            if osmatch is not None:
                host_data["os"] = {
                    "name": osmatch.get("name"),
                    "accuracy": int(osmatch.get("accuracy", 0)),
                    "line": osmatch.get("line"),
                }
        
        return host_data
    
    def _parse_port_element(self, port_elem: ET.Element) -> Dict[str, Any]:
        """Parse port element from Nmap XML"""
        port_data = {
            "protocol": port_elem.get("protocol", "tcp"),
            "portid": int(port_elem.get("portid", 0)),
            "state": "unknown",
            "service": {},
            "scripts": [],
        }
        
        # State
        state_elem = port_elem.find("state")
        if state_elem is not None:
            port_data["state"] = state_elem.get("state", "unknown")
        
        # Service
        service_elem = port_elem.find("service")
        if service_elem is not None:
            port_data["service"] = {
                "name": service_elem.get("name"),
                "product": service_elem.get("product"),
                "version": service_elem.get("version"),
                "extrainfo": service_elem.get("extrainfo"),
                "ostype": service_elem.get("ostype"),
                "method": service_elem.get("method"),
                "conf": int(service_elem.get("conf", 0)),
                "cpe": [cpe.text for cpe in service_elem.findall("cpe")],
            }
        
        # Scripts (NSE)
        for script in port_elem.findall("script"):
            port_data["scripts"].append({
                "id": script.get("id"),
                "output": script.get("output"),
            })
        
        return port_data
    
    def _parse_grepable(self, output: str) -> Dict[str, Any]:
        """Parse Nmap grepable output (-oG)"""
        result = {"hosts": []}
        
        for line in output.split("\n"):
            if line.startswith("Host:"):
                parts = line.split("\t")
                host_data = {"addresses": {}, "ports": []}
                
                # Parse host line
                host_match = re.search(r'Host:\s+(\S+)', line)
                if host_match:
                    host_data["addresses"]["ipv4"] = {"addr": host_match.group(1)}
                
                # Parse ports
                ports_match = re.search(r'Ports:\s+(.+)', line)
                if ports_match:
                    ports_str = ports_match.group(1)
                    for port_info in ports_str.split(", "):
                        port_parts = port_info.split("/")
                        if len(port_parts) >= 4:
                            host_data["ports"].append({
                                "portid": int(port_parts[0]),
                                "state": port_parts[1],
                                "protocol": port_parts[2],
                                "service": {"name": port_parts[4]} if len(port_parts) > 4 else {},
                            })
                
                result["hosts"].append(host_data)
        
        return result
    
    def normalize(self, parsed_data: Dict[str, Any]) -> Dict[str, List]:
        """Normalize parsed Nmap data into entity models"""
        result = {
            "hosts": [],
            "ports": [],
            "services": [],
            "vulnerabilities": [],
        }
        
        for host_data in parsed_data.get("hosts", []):
            # Create Host
            ip_addr = host_data.get("addresses", {}).get("ipv4", {}).get("addr", "")
            if not ip_addr:
                continue
            
            host = Host(
                ip=ip_addr,
                hostname=host_data.get("hostnames", [{}])[0].get("name") if host_data.get("hostnames") else None,
                mac_address=host_data.get("addresses", {}).get("mac", {}).get("addr"),
                status=HostStatus.UP if host_data.get("status") == "up" else HostStatus.DOWN,
                source_tool="nmap",
            )
            
            # OS info
            os_data = host_data.get("os", {})
            if os_data:
                host.os_name = os_data.get("name")
                host.os_accuracy = os_data.get("accuracy", 0)
            
            # Process ports
            for port_data in host_data.get("ports", []):
                if port_data.get("state") != "open":
                    continue
                
                # Create Port
                protocol = ServiceProtocol.TCP if port_data.get("protocol") == "tcp" else ServiceProtocol.UDP
                port = Port(
                    number=port_data.get("portid", 0),
                    protocol=protocol,
                    state=PortState.OPEN,
                    source_tool="nmap",
                )
                
                # Service info
                svc_data = port_data.get("service", {})
                if svc_data:
                    port.service_name = svc_data.get("name")
                    port.service_version = svc_data.get("version")
                    port.banner = svc_data.get("extrainfo")
                    port.confidence = svc_data.get("conf", 100) / 100.0
                    
                    # Create Service
                    service = Service(
                        name=svc_data.get("name", "unknown"),
                        product=svc_data.get("product"),
                        version=svc_data.get("version"),
                        extra_info=svc_data.get("extrainfo"),
                        os_type=svc_data.get("ostype"),
                        cpe=svc_data.get("cpe", []),
                    )
                    
                    host.services[f"{protocol}/{port.number}"] = service
                    result["services"].append(service)
                
                # Check for vulnerabilities in scripts
                for script in port_data.get("scripts", []):
                    vuln = self._parse_vulnerability_from_script(script)
                    if vuln:
                        vuln.affected_service = port.service_name
                        host.vulnerabilities.append(vuln)
                        result["vulnerabilities"].append(vuln)
                
                host.add_port(port)
                result["ports"].append(port)
            
            result["hosts"].append(host)
        
        return result
    
    def _parse_vulnerability_from_script(self, script: Dict) -> Optional[Vulnerability]:
        """Extract vulnerability info from NSE script output"""
        script_id = script.get("id", "").lower()
        output = script.get("output", "")
        
        # Vulnerability scripts
        vuln_scripts = ["vulners", "cve", "vuln", "exploit"]
        
        if any(vs in script_id for vs in vuln_scripts):
            # Try to extract CVE IDs
            cve_pattern = r'CVE-\d{4}-\d{4,7}'
            cves = re.findall(cve_pattern, output)
            
            if cves:
                return Vulnerability(
                    cve_id=cves[0],
                    name=f"Vulnerability detected by {script_id}",
                    description=output[:500],
                    severity=VulnerabilitySeverity.HIGH if cves else VulnerabilitySeverity.INFO,
                    source_tool=f"nmap:{script_id}",
                )
        
        return None


# ═══════════════════════════════════════════════════════════════════════════════
# Gobuster Normalizer
# ═══════════════════════════════════════════════════════════════════════════════

class GobusterNormalizer(ToolNormalizer):
    """Normalizer for Gobuster directory/file enumeration"""
    
    tool_name = "gobuster"
    supported_formats = ["json", "text"]
    
    def parse(self, output: ToolOutput) -> Dict[str, Any]:
        """Parse Gobuster output"""
        result = {
            "found_urls": [],
            "errors": [],
        }
        
        # Try JSON first
        try:
            return json.loads(output.stdout)
        except json.JSONDecodeError:
            pass
        
        # Parse text output
        for line in output.stdout.split("\n"):
            line = line.strip()
            
            # Skip empty lines and progress
            if not line or line.startswith("["):
                continue
            
            # Parse found URL
            # Format: /path (Status: 200) [Size: 1234]
            match = re.match(r'(\S+)\s+\(Status:\s*(\d+)\)\s+\[Size:\s*(\d+)\]', line)
            if match:
                result["found_urls"].append({
                    "url": match.group(1),
                    "status_code": int(match.group(2)),
                    "size": int(match.group(3)),
                })
            elif "Error:" in line:
                result["errors"].append(line)
        
        return result
    
    def normalize(self, parsed_data: Dict[str, Any]) -> Dict[str, List]:
        """Normalize into standard format"""
        result = {
            "urls": [],
            "services": [],
        }
        
        for url_data in parsed_data.get("found_urls", []):
            # Could create WebEndpoint model here
            result["urls"].append({
                "path": url_data.get("url"),
                "status_code": url_data.get("status_code"),
                "size": url_data.get("size"),
            })
        
        return result


# ═══════════════════════════════════════════════════════════════════════════════
# SQLMap Normalizer
# ═══════════════════════════════════════════════════════════════════════════════

class SQLMapNormalizer(ToolNormalizer):
    """Normalizer for SQLMap SQL injection testing"""
    
    tool_name = "sqlmap"
    supported_formats = ["json", "text"]
    
    def parse(self, output: ToolOutput) -> Dict[str, Any]:
        """Parse SQLMap output"""
        result = {
            "vulnerable": False,
            "injection_points": [],
            "dbs": [],
            "tables": [],
            "columns": [],
            "data": [],
            "techniques": [],
        }
        
        stdout = output.stdout
        
        # Check if vulnerable
        if "is vulnerable" in stdout.lower() or "injectable" in stdout.lower():
            result["vulnerable"] = True
        
        # Extract injection points
        injection_pattern = r'Parameter\s+\'(\w+)\'\s+is\s+vulnerable'
        for match in re.finditer(injection_pattern, stdout):
            result["injection_points"].append({
                "parameter": match.group(1),
                "type": "unknown",
            })
        
        # Extract techniques
        techniques = ["boolean-based", "time-based", "error-based", "union query", "stacked queries"]
        for tech in techniques:
            if tech in stdout.lower():
                result["techniques"].append(tech)
        
        # Extract database names
        db_pattern = r'available databases? \[(\d+)\]:([\s\S]+?)(?=\n\n|\Z)'
        db_match = re.search(db_pattern, stdout)
        if db_match:
            dbs_text = db_match.group(2)
            result["dbs"] = [db.strip()[2:] for db in dbs_text.split("\n") if db.strip().startswith("[*]")]
        
        return result
    
    def normalize(self, parsed_data: Dict[str, Any]) -> Dict[str, List]:
        """Normalize into vulnerabilities"""
        result = {
            "vulnerabilities": [],
            "credentials": [],
        }
        
        if parsed_data.get("vulnerable"):
            for injection in parsed_data.get("injection_points", []):
                vuln = Vulnerability(
                    name=f"SQL Injection - {injection.get('parameter')}",
                    description=f"Parameter '{injection.get('parameter')}' is vulnerable to SQL injection. "
                               f"Techniques: {', '.join(parsed_data.get('techniques', []))}",
                    severity=VulnerabilitySeverity.CRITICAL,
                    source_tool="sqlmap",
                )
                result["vulnerabilities"].append(vuln)
        
        return result


# ═══════════════════════════════════════════════════════════════════════════════
# Hydra Normalizer
# ═══════════════════════════════════════════════════════════════════════════════

class HydraNormalizer(ToolNormalizer):
    """Normalizer for Hydra credential bruteforce"""
    
    tool_name = "hydra"
    supported_formats = ["text"]
    
    def parse(self, output: ToolOutput) -> Dict[str, Any]:
        """Parse Hydra output"""
        result = {
            "valid_credentials": [],
            "attempts": 0,
            "hosts": [],
        }
        
        for line in output.stdout.split("\n"):
            # Valid credential format
            # [22][ssh] host: 192.168.1.1   login: admin   password: password123
            match = re.match(r'\[(\d+)\]\[(\w+)\]\s+host:\s+(\S+)\s+login:\s+(\S+)\s+password:\s+(\S+)', line)
            if match:
                result["valid_credentials"].append({
                    "port": int(match.group(1)),
                    "protocol": match.group(2),
                    "host": match.group(3),
                    "username": match.group(4),
                    "password": match.group(5),
                })
                if match.group(3) not in result["hosts"]:
                    result["hosts"].append(match.group(3))
        
        return result
    
    def normalize(self, parsed_data: Dict[str, Any]) -> Dict[str, List]:
        """Normalize into credentials"""
        result = {
            "credentials": [],
            "hosts": [],
        }
        
        for cred_data in parsed_data.get("valid_credentials", []):
            credential = Credential(
                username=cred_data.get("username"),
                password=cred_data.get("password"),
                service=cred_data.get("protocol"),
                source="hydra",
                validated=True,
                validation_method="brute_force",
            )
            result["credentials"].append(credential)
        
        return result


# ═══════════════════════════════════════════════════════════════════════════════
# Nuclei Normalizer
# ═══════════════════════════════════════════════════════════════════════════════

class NucleiNormalizer(ToolNormalizer):
    """Normalizer for Nuclei vulnerability scanner"""
    
    tool_name = "nuclei"
    supported_formats = ["json"]
    
    def parse(self, output: ToolOutput) -> Dict[str, Any]:
        """Parse Nuclei JSON output"""
        result = {
            "findings": [],
        }
        
        # Nuclei outputs one JSON object per line
        for line in output.stdout.strip().split("\n"):
            if not line:
                continue
            try:
                finding = json.loads(line)
                result["findings"].append(finding)
            except json.JSONDecodeError:
                continue
        
        return result
    
    def normalize(self, parsed_data: Dict[str, Any]) -> Dict[str, List]:
        """Normalize into vulnerabilities"""
        result = {
            "vulnerabilities": [],
            "hosts": [],
        }
        
        severity_map = {
            "critical": VulnerabilitySeverity.CRITICAL,
            "high": VulnerabilitySeverity.HIGH,
            "medium": VulnerabilitySeverity.MEDIUM,
            "low": VulnerabilitySeverity.LOW,
            "info": VulnerabilitySeverity.INFO,
        }
        
        for finding in parsed_data.get("findings", []):
            info = finding.get("info", {})
            
            vuln = Vulnerability(
                name=info.get("name", "Unknown"),
                description=info.get("description", ""),
                severity=severity_map.get(info.get("severity", "info").lower(), VulnerabilitySeverity.INFO),
                source_tool=f"nuclei:{finding.get('template-id', 'unknown')}",
            )
            
            # Extract matched URL/host
            host = finding.get("host", "")
            if host:
                result["hosts"].append({"url": host})
            
            result["vulnerabilities"].append(vuln)
        
        return result


# ═══════════════════════════════════════════════════════════════════════════════
# Tool Registry
# ═══════════════════════════════════════════════════════════════════════════════

class ToolRegistry:
    """Registry of all available tool normalizers"""
    
    def __init__(self):
        self._normalizers: Dict[str, Type[ToolNormalizer]] = {}
        self._register_defaults()
    
    def _register_defaults(self):
        """Register default normalizers"""
        self.register("nmap", NmapNormalizer)
        self.register("gobuster", GobusterNormalizer)
        self.register("sqlmap", SQLMapNormalizer)
        self.register("hydra", HydraNormalizer)
        self.register("nuclei", NucleiNormalizer)
    
    def register(self, tool_name: str, normalizer_class: Type[ToolNormalizer]) -> None:
        """Register a new normalizer"""
        self._normalizers[tool_name.lower()] = normalizer_class
    
    def get(self, tool_name: str) -> Optional[ToolNormalizer]:
        """Get normalizer for a tool"""
        normalizer_class = self._normalizers.get(tool_name.lower())
        if normalizer_class:
            return normalizer_class()
        return None
    
    def list_tools(self) -> List[str]:
        """List all registered tools"""
        return list(self._normalizers.keys())
    
    def process(self, tool_name: str, output: ToolOutput) -> Dict[str, List]:
        """Process output for a specific tool"""
        normalizer = self.get(tool_name)
        if normalizer:
            return normalizer.process(output)
        
        # Return empty result if no normalizer found
        return {
            "hosts": [],
            "ports": [],
            "services": [],
            "vulnerabilities": [],
            "credentials": [],
            "raw_output": [output.stdout],
        }


# Global registry instance
_tool_registry = ToolRegistry()


def get_tool_registry() -> ToolRegistry:
    """Get the global tool registry"""
    return _tool_registry


# ═══════════════════════════════════════════════════════════════════════════════
# Enrichment Layer
# ═══════════════════════════════════════════════════════════════════════════════

class DataEnricher:
    """Enrich discovered data with CVE and exploit information"""
    
    def __init__(self, cve_db_path: Optional[str] = None, exploit_db_path: Optional[str] = None):
        self.cve_db_path = cve_db_path
        self.exploit_db_path = exploit_db_path
    
    def enrich_service(self, service: Service) -> List[Vulnerability]:
        """
        Enrich service with known vulnerabilities from CVE database
        
        Args:
            service: Service to enrich
            
        Returns:
            List of vulnerabilities
        """
        vulnerabilities = []
        
        # Search CVEs by CPE
        for cpe in service.cpe:
            cves = self._search_cve_by_cpe(cpe)
            for cve in cves:
                vuln = Vulnerability(
                    cve_id=cve.get("id"),
                    name=cve.get("summary", "")[:100],
                    description=cve.get("summary"),
                    severity=self._cvss_to_severity(cve.get("cvss", 0)),
                    cvss_score=cve.get("cvss"),
                    affected_service=service.name,
                    exploit_available=self._check_exploit_available(cve.get("id")),
                )
                vulnerabilities.append(vuln)
        
        # Search by service name and version
        if service.name and service.version:
            cves = self._search_cve_by_product(service.name, service.version)
            for cve in cves:
                vuln = Vulnerability(
                    cve_id=cve.get("id"),
                    name=cve.get("summary", "")[:100],
                    description=cve.get("summary"),
                    severity=self._cvss_to_severity(cve.get("cvss", 0)),
                    cvss_score=cve.get("cvss"),
                    affected_service=service.name,
                    affected_versions=[service.version],
                    exploit_available=self._check_exploit_available(cve.get("id")),
                )
                if vuln.cve_id not in [v.cve_id for v in vulnerabilities]:
                    vulnerabilities.append(vuln)
        
        return vulnerabilities
    
    def _search_cve_by_cpe(self, cpe: str) -> List[Dict]:
        """Search CVEs by CPE (placeholder - implement with actual CVE DB)"""
        # TODO: Implement with local CVE database
        return []
    
    def _search_cve_by_product(self, product: str, version: str) -> List[Dict]:
        """Search CVEs by product name and version"""
        # TODO: Implement with local CVE database
        return []
    
    def _check_exploit_available(self, cve_id: Optional[str]) -> bool:
        """Check if exploit is available for CVE"""
        if not cve_id:
            return False
        # TODO: Check exploit-db
        return False
    
    def _cvss_to_severity(self, cvss: float) -> VulnerabilitySeverity:
        """Convert CVSS score to severity"""
        if cvss >= 9.0:
            return VulnerabilitySeverity.CRITICAL
        elif cvss >= 7.0:
            return VulnerabilitySeverity.HIGH
        elif cvss >= 4.0:
            return VulnerabilitySeverity.MEDIUM
        elif cvss > 0:
            return VulnerabilitySeverity.LOW
        return VulnerabilitySeverity.INFO


# Example usage
if __name__ == "__main__":
    # Test Nmap normalizer
    nmap_xml = """<?xml version="1.0" encoding="UTF-8"?>
    <nmaprun>
      <host>
        <status state="up"/>
        <address addr="192.168.1.1" addrtype="ipv4"/>
        <hostnames>
          <hostname name="router.local" type="PTR"/>
        </hostnames>
        <ports>
          <port protocol="tcp" portid="80">
            <state state="open"/>
            <service name="http" product="nginx" version="1.18.0"/>
          </port>
          <port protocol="tcp" portid="443">
            <state state="open"/>
            <service name="https" product="nginx" version="1.18.0"/>
          </port>
        </ports>
      </host>
    </nmaprun>
    """
    
    tool_output = ToolOutput(
        tool_name="nmap",
        command="nmap -sV -oX - 192.168.1.1",
        exit_code=0,
        stdout=nmap_xml,
        stderr="",
        execution_time_ms=5000,
    )
    
    registry = get_tool_registry()
    result = registry.process("nmap", tool_output)
    
    print("=== Tool Layer Test ===")
    print(f"Hosts found: {len(result['hosts'])}")
    print(f"Ports found: {len(result['ports'])}")
    print(f"Services found: {len(result['services'])}")
    
    for host in result['hosts']:
        print(f"\nHost: {host.ip}")
        print(f"  Status: {host.status}")
        print(f"  Open ports: {len(host.get_open_ports())}")
        for port in host.get_open_ports():
            print(f"    - {port.protocol}/{port.number}: {port.service_name}")
