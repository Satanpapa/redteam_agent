"""
World Model - Graph-based knowledge representation for Red Team Agent
Uses NetworkX for in-memory graph operations and SQLite for persistence
"""

from __future__ import annotations

import json
import logging
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import networkx as nx
from networkx.algorithms import shortest_path

from models import (
    Credential,
    Exploit,
    Host,
    HostStatus,
    NetworkSegment,
    Port,
    PortState,
    Service,
    ServiceProtocol,
    Vulnerability,
    VulnerabilitySeverity,
)

logger = logging.getLogger(__name__)


class WorldModel:
    """
    Graph-based knowledge model for the red team agent
    
    Structure:
        Hosts → Ports → Services → Vulnerabilities → Exploits
          ↓         ↓
        Network  Credentials
    
    Uses NetworkX for graph operations and SQLite for persistence
    """
    
    def __init__(self, db_path: str = "./data/world_model.db"):
        """
        Initialize World Model
        
        Args:
            db_path: Path to SQLite database
        """
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        
        # In-memory graph
        self.graph = nx.DiGraph()
        
        # Entity stores for quick access
        self._hosts: Dict[str, Host] = {}
        self._ports: Dict[str, Port] = {}
        self._services: Dict[str, Service] = {}
        self._vulnerabilities: Dict[str, Vulnerability] = {}
        self._exploits: Dict[str, Exploit] = {}
        self._credentials: Dict[str, Credential] = {}
        self._network_segments: Dict[str, NetworkSegment] = {}
        
        # Initialize database
        self._init_database()
        
        # Load existing data
        self._load_from_db()
    
    def _init_database(self) -> None:
        """Initialize SQLite database schema"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Hosts table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS hosts (
                    id TEXT PRIMARY KEY,
                    ip TEXT NOT NULL UNIQUE,
                    hostname TEXT,
                    mac_address TEXT,
                    subnet TEXT,
                    gateway TEXT,
                    os_name TEXT,
                    os_version TEXT,
                    os_family TEXT,
                    os_accuracy INTEGER DEFAULT 0,
                    status TEXT DEFAULT 'unknown',
                    compromised INTEGER DEFAULT 0,
                    compromise_method TEXT,
                    compromise_time TEXT,
                    access_level TEXT,
                    discovered_at TEXT,
                    last_seen TEXT,
                    source_tool TEXT,
                    tags TEXT,
                    notes TEXT,
                    data TEXT
                )
            """)
            
            # Ports table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS ports (
                    id TEXT PRIMARY KEY,
                    host_id TEXT NOT NULL,
                    number INTEGER NOT NULL,
                    protocol TEXT NOT NULL,
                    state TEXT DEFAULT 'closed',
                    service_name TEXT,
                    service_version TEXT,
                    banner TEXT,
                    discovered_at TEXT,
                    source_tool TEXT,
                    confidence REAL DEFAULT 1.0,
                    FOREIGN KEY (host_id) REFERENCES hosts(id),
                    UNIQUE(host_id, number, protocol)
                )
            """)
            
            # Services table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS services (
                    id TEXT PRIMARY KEY,
                    host_id TEXT NOT NULL,
                    port_id TEXT NOT NULL,
                    name TEXT NOT NULL,
                    version TEXT,
                    product TEXT,
                    extra_info TEXT,
                    os_type TEXT,
                    http_title TEXT,
                    http_methods TEXT,
                    web_technologies TEXT,
                    cpe TEXT,
                    discovered_at TEXT,
                    FOREIGN KEY (host_id) REFERENCES hosts(id),
                    FOREIGN KEY (port_id) REFERENCES ports(id)
                )
            """)
            
            # Vulnerabilities table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS vulnerabilities (
                    id TEXT PRIMARY KEY,
                    cve_id TEXT,
                    name TEXT NOT NULL,
                    description TEXT,
                    severity TEXT DEFAULT 'info',
                    cvss_score REAL,
                    affected_service TEXT,
                    affected_versions TEXT,
                    exploit_available INTEGER DEFAULT 0,
                    exploit_ids TEXT,
                    discovered_at TEXT,
                    verified INTEGER DEFAULT 0,
                    false_positive INTEGER DEFAULT 0,
                    notes TEXT,
                    host_id TEXT,
                    FOREIGN KEY (host_id) REFERENCES hosts(id)
                )
            """)
            
            # Credentials table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS credentials (
                    id TEXT PRIMARY KEY,
                    username TEXT,
                    password TEXT,
                    hash_value TEXT,
                    hash_type TEXT,
                    service TEXT,
                    host_id TEXT,
                    source TEXT,
                    validated INTEGER DEFAULT 0,
                    validation_method TEXT,
                    discovered_at TEXT,
                    FOREIGN KEY (host_id) REFERENCES hosts(id)
                )
            """)
            
            # Network segments table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS network_segments (
                    id TEXT PRIMARY KEY,
                    cidr TEXT NOT NULL UNIQUE,
                    name TEXT,
                    description TEXT,
                    host_ids TEXT,
                    discovered_at TEXT
                )
            """)
            
            # Graph edges table (for persistence)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS graph_edges (
                    source TEXT NOT NULL,
                    target TEXT NOT NULL,
                    relation TEXT NOT NULL,
                    properties TEXT,
                    PRIMARY KEY (source, target, relation)
                )
            """)
            
            # Indexes
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_hosts_ip ON hosts(ip)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_hosts_status ON hosts(status)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_ports_host ON ports(host_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_vulns_severity ON vulnerabilities(severity)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_vulns_cve ON vulnerabilities(cve_id)")
            
            conn.commit()
            logger.info("Database schema initialized")
    
    def _load_from_db(self) -> None:
        """Load data from database into memory"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                
                # Load hosts
                cursor.execute("SELECT * FROM hosts")
                for row in cursor.fetchall():
                    host = self._row_to_host(row)
                    self._hosts[host.id] = host
                    self.graph.add_node(
                        host.id,
                        type="host",
                        data=host
                    )
                
                # Load ports
                cursor.execute("SELECT * FROM ports")
                for row in cursor.fetchall():
                    port = self._row_to_port(row)
                    port_id = f"{row['host_id']}/{row['protocol']}/{row['number']}"
                    self._ports[port_id] = port
                    self.graph.add_node(
                        port_id,
                        type="port",
                        data=port
                    )
                    # Add edge: host -> port
                    self.graph.add_edge(
                        row['host_id'],
                        port_id,
                        relation="HAS_PORT"
                    )
                
                # Load services
                cursor.execute("SELECT * FROM services")
                for row in cursor.fetchall():
                    service = self._row_to_service(row)
                    svc_id = row['id']
                    self._services[svc_id] = service
                    self.graph.add_node(
                        svc_id,
                        type="service",
                        data=service
                    )
                    # Add edge: port -> service
                    self.graph.add_edge(
                        row['port_id'],
                        svc_id,
                        relation="RUNS_SERVICE"
                    )
                
                # Load vulnerabilities
                cursor.execute("SELECT * FROM vulnerabilities")
                for row in cursor.fetchall():
                    vuln = self._row_to_vulnerability(row)
                    self._vulnerabilities[vuln.id] = vuln
                    self.graph.add_node(
                        vuln.id,
                        type="vulnerability",
                        data=vuln
                    )
                    # Add edge: service -> vulnerability (if service known)
                    if row['affected_service']:
                        for svc_id, svc in self._services.items():
                            if svc.name == row['affected_service']:
                                self.graph.add_edge(
                                    svc_id,
                                    vuln.id,
                                    relation="HAS_VULNERABILITY"
                                )
                
                # Load credentials
                cursor.execute("SELECT * FROM credentials")
                for row in cursor.fetchall():
                    cred = self._row_to_credential(row)
                    self._credentials[cred.id] = cred
                    self.graph.add_node(
                        cred.id,
                        type="credential",
                        data=cred
                    )
                    # Add edge: host -> credential
                    if row['host_id']:
                        self.graph.add_edge(
                            row['host_id'],
                            cred.id,
                            relation="HAS_CREDENTIAL"
                        )
                
                # Load edges
                cursor.execute("SELECT * FROM graph_edges")
                for row in cursor.fetchall():
                    props = json.loads(row['properties']) if row['properties'] else {}
                    self.graph.add_edge(
                        row['source'],
                        row['target'],
                        relation=row['relation'],
                        **props
                    )
                
                logger.info(f"Loaded from DB: {len(self._hosts)} hosts, "
                           f"{len(self._ports)} ports, {len(self._services)} services, "
                           f"{len(self._vulnerabilities)} vulns, {len(self._credentials)} creds")
                
        except Exception as e:
            logger.warning(f"Failed to load from DB: {e}")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # Entity Conversion Methods
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _row_to_host(self, row: sqlite3.Row) -> Host:
        """Convert database row to Host"""
        data = json.loads(row['data']) if row['data'] else {}
        return Host(
            id=row['id'],
            ip=row['ip'],
            hostname=row['hostname'],
            mac_address=row['mac_address'],
            subnet=row['subnet'],
            gateway=row['gateway'],
            os_name=row['os_name'],
            os_version=row['os_version'],
            os_family=row['os_family'],
            os_accuracy=row['os_accuracy'],
            status=HostStatus(row['status']),
            compromised=bool(row['compromised']),
            compromise_method=row['compromise_method'],
            compromise_time=datetime.fromisoformat(row['compromise_time']) if row['compromise_time'] else None,
            access_level=row['access_level'],
            discovered_at=datetime.fromisoformat(row['discovered_at']),
            last_seen=datetime.fromisoformat(row['last_seen']) if row['last_seen'] else datetime.utcnow(),
            source_tool=row['source_tool'],
            tags=set(json.loads(row['tags'])) if row['tags'] else set(),
            notes=row['notes'],
            **data
        )
    
    def _row_to_port(self, row: sqlite3.Row) -> Port:
        """Convert database row to Port"""
        return Port(
            number=row['number'],
            protocol=ServiceProtocol(row['protocol']),
            state=PortState(row['state']),
            service_name=row['service_name'],
            service_version=row['service_version'],
            banner=row['banner'],
            discovered_at=datetime.fromisoformat(row['discovered_at']),
            source_tool=row['source_tool'],
            confidence=row['confidence'],
        )
    
    def _row_to_service(self, row: sqlite3.Row) -> Service:
        """Convert database row to Service"""
        return Service(
            name=row['name'],
            version=row['version'],
            product=row['product'],
            extra_info=row['extra_info'],
            os_type=row['os_type'],
            http_title=row['http_title'],
            http_methods=json.loads(row['http_methods']) if row['http_methods'] else [],
            web_technologies=json.loads(row['web_technologies']) if row['web_technologies'] else [],
            cpe=json.loads(row['cpe']) if row['cpe'] else [],
            discovered_at=datetime.fromisoformat(row['discovered_at']),
        )
    
    def _row_to_vulnerability(self, row: sqlite3.Row) -> Vulnerability:
        """Convert database row to Vulnerability"""
        return Vulnerability(
            id=row['id'],
            cve_id=row['cve_id'],
            name=row['name'],
            description=row['description'],
            severity=VulnerabilitySeverity(row['severity']),
            cvss_score=row['cvss_score'],
            affected_service=row['affected_service'],
            affected_versions=json.loads(row['affected_versions']) if row['affected_versions'] else [],
            exploit_available=bool(row['exploit_available']),
            exploit_ids=json.loads(row['exploit_ids']) if row['exploit_ids'] else [],
            discovered_at=datetime.fromisoformat(row['discovered_at']),
            verified=bool(row['verified']),
            false_positive=bool(row['false_positive']),
            notes=row['notes'],
        )
    
    def _row_to_credential(self, row: sqlite3.Row) -> Credential:
        """Convert database row to Credential"""
        return Credential(
            id=row['id'],
            username=row['username'],
            password=row['password'],
            hash_value=row['hash_value'],
            hash_type=row['hash_type'],
            service=row['service'],
            host_id=row['host_id'],
            source=row['source'],
            validated=bool(row['validated']),
            validation_method=row['validation_method'],
            discovered_at=datetime.fromisoformat(row['discovered_at']),
        )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CRUD Operations
    # ═══════════════════════════════════════════════════════════════════════════
    
    def add_host(self, host: Host) -> Optional[str]:
        """
        Add or update a host
        
        Args:
            host: Host to add
            
        Returns:
            Host ID if added/updated, None if skipped
        """
        # Check if host already exists by IP
        existing = self.get_host_by_ip(host.ip)
        if existing:
            # Update existing host
            host.id = existing.id
            self._update_host(host)
            return host.id
        
        # Add new host
        self._hosts[host.id] = host
        self.graph.add_node(host.id, type="host", data=host)
        
        # Persist to database
        self._persist_host(host)
        
        logger.debug(f"Added host: {host.ip}")
        return host.id
    
    def _persist_host(self, host: Host) -> None:
        """Persist host to database"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO hosts 
                (id, ip, hostname, mac_address, subnet, gateway, os_name, os_version,
                 os_family, os_accuracy, status, compromised, compromise_method, compromise_time,
                 access_level, discovered_at, last_seen, source_tool, tags, notes, data)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                host.id, host.ip, host.hostname, host.mac_address, host.subnet,
                host.gateway, host.os_name, host.os_version, host.os_family,
                host.os_accuracy, host.status.value, int(host.compromised),
                host.compromise_method,
                host.compromise_time.isoformat() if host.compromise_time else None,
                host.access_level, host.discovered_at.isoformat(),
                host.last_seen.isoformat(), host.source_tool,
                json.dumps(list(host.tags)), host.notes,
                json.dumps({"ports": {}, "services": {}, "vulnerabilities": [], "credentials": []})
            ))
            conn.commit()
    
    def _update_host(self, host: Host) -> None:
        """Update existing host"""
        self._hosts[host.id] = host
        self.graph.nodes[host.id]['data'] = host
        self._persist_host(host)
    
    def get_host(self, host_id: str) -> Optional[Host]:
        """Get host by ID"""
        return self._hosts.get(host_id)
    
    def get_host_by_ip(self, ip: str) -> Optional[Host]:
        """Get host by IP address"""
        for host in self._hosts.values():
            if host.ip == ip:
                return host
        return None
    
    def add_port(self, port: Port, host_id: Optional[str] = None) -> str:
        """Add a port to a host"""
        port_id = f"{host_id}/{port.protocol.value}/{port.number}"
        
        self._ports[port_id] = port
        self.graph.add_node(port_id, type="port", data=port)
        
        if host_id:
            self.graph.add_edge(host_id, port_id, relation="HAS_PORT")
            
            # Update host's ports
            host = self._hosts.get(host_id)
            if host:
                host.add_port(port)
        
        self._persist_port(port_id, port, host_id)
        return port_id
    
    def _persist_port(self, port_id: str, port: Port, host_id: Optional[str]) -> None:
        """Persist port to database"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO ports 
                (id, host_id, number, protocol, state, service_name, service_version,
                 banner, discovered_at, source_tool, confidence)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                port_id, host_id, port.number, port.protocol.value, port.state.value,
                port.service_name, port.service_version, port.banner,
                port.discovered_at.isoformat(), port.source_tool, port.confidence
            ))
            conn.commit()
    
    def add_service(self, service: Service, host_id: Optional[str] = None, port_id: Optional[str] = None) -> str:
        """Add a service"""
        import uuid
        svc_id = str(uuid.uuid4())
        
        self._services[svc_id] = service
        self.graph.add_node(svc_id, type="service", data=service)
        
        if port_id:
            self.graph.add_edge(port_id, svc_id, relation="RUNS_SERVICE")
        
        self._persist_service(svc_id, service, host_id, port_id)
        return svc_id
    
    def _persist_service(self, svc_id: str, service: Service, host_id: Optional[str], port_id: Optional[str]) -> None:
        """Persist service to database"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO services 
                (id, host_id, port_id, name, version, product, extra_info, os_type,
                 http_title, http_methods, web_technologies, cpe, discovered_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                svc_id, host_id, port_id, service.name, service.version,
                service.product, service.extra_info, service.os_type,
                service.http_title, json.dumps(service.http_methods),
                json.dumps(service.web_technologies), json.dumps(service.cpe),
                service.discovered_at.isoformat()
            ))
            conn.commit()
    
    def add_vulnerability(self, vuln: Vulnerability, host_id: Optional[str] = None) -> str:
        """Add a vulnerability"""
        self._vulnerabilities[vuln.id] = vuln
        self.graph.add_node(vuln.id, type="vulnerability", data=vuln)
        
        if host_id:
            self.graph.add_edge(host_id, vuln.id, relation="HAS_VULNERABILITY")
            host = self._hosts.get(host_id)
            if host:
                host.vulnerabilities.append(vuln)
        
        self._persist_vulnerability(vuln, host_id)
        return vuln.id
    
    def _persist_vulnerability(self, vuln: Vulnerability, host_id: Optional[str]) -> None:
        """Persist vulnerability to database"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO vulnerabilities 
                (id, cve_id, name, description, severity, cvss_score, affected_service,
                 affected_versions, exploit_available, exploit_ids, discovered_at,
                 verified, false_positive, notes, host_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                vuln.id, vuln.cve_id, vuln.name, vuln.description,
                vuln.severity.value, vuln.cvss_score, vuln.affected_service,
                json.dumps(vuln.affected_versions), int(vuln.exploit_available),
                json.dumps(vuln.exploit_ids), vuln.discovered_at.isoformat(),
                int(vuln.verified), int(vuln.false_positive), vuln.notes, host_id
            ))
            conn.commit()
    
    # ═══════════════════════════════════════════════════════════════════════════
    # Query Methods
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_hosts(self, status: Optional[HostStatus] = None) -> List[Host]:
        """Get all hosts, optionally filtered by status"""
        hosts = list(self._hosts.values())
        if status:
            hosts = [h for h in hosts if h.status == status]
        return hosts
    
    def get_compromised_hosts(self) -> List[Host]:
        """Get all compromised hosts"""
        return [h for h in self._hosts.values() if h.compromised]
    
    def get_vulnerable_hosts(self, min_severity: VulnerabilitySeverity = VulnerabilitySeverity.MEDIUM) -> List[Host]:
        """Get hosts with vulnerabilities"""
        severity_order = [
            VulnerabilitySeverity.INFO,
            VulnerabilitySeverity.LOW,
            VulnerabilitySeverity.MEDIUM,
            VulnerabilitySeverity.HIGH,
            VulnerabilitySeverity.CRITICAL,
        ]
        min_index = severity_order.index(min_severity)
        
        result = []
        for host in self._hosts.values():
            for vuln in host.vulnerabilities:
                if severity_order.index(vuln.severity) >= min_index:
                    result.append(host)
                    break
        return result
    
    def get_attack_paths(self, from_host: str, to_host: str) -> List[List[str]]:
        """
        Find all attack paths between two hosts
        
        Returns:
            List of paths (each path is a list of node IDs)
        """
        try:
            paths = list(nx.all_simple_paths(
                self.graph,
                source=from_host,
                target=to_host,
                cutoff=10
            ))
            return paths
        except nx.NetworkXNoPath:
            return []
    
    def get_shortest_attack_path(self, from_host: str, to_host: str) -> Optional[List[str]]:
        """Get shortest attack path between hosts"""
        try:
            return shortest_path(self.graph, source=from_host, target=to_host)
        except nx.NetworkXNoPath:
            return None
    
    def find_services_by_name(self, name: str) -> List[Tuple[str, Service]]:
        """Find all services matching a name pattern"""
        results = []
        name_lower = name.lower()
        for svc_id, service in self._services.items():
            if name_lower in service.name.lower():
                results.append((svc_id, service))
        return results
    
    def find_vulnerabilities_by_cve(self, cve_id: str) -> List[Vulnerability]:
        """Find vulnerabilities by CVE ID"""
        return [v for v in self._vulnerabilities.values() if v.cve_id == cve_id]
    
    def get_services_with_exploits(self) -> List[Tuple[str, Service, List[Exploit]]]:
        """Get services that have known exploits"""
        results = []
        for svc_id, service in self._services.items():
            exploits = self._find_exploits_for_service(service)
            if exploits:
                results.append((svc_id, service, exploits))
        return results
    
    def _find_exploits_for_service(self, service: Service) -> List[Exploit]:
        """Find exploits for a service"""
        exploits = []
        for exploit in self._exploits.values():
            if service.name in exploit.targets_services:
                exploits.append(exploit)
            # Check CPE match
            for cpe in service.cpe:
                if any(cpe in target_cpe for target_cpe in exploit.targets_cve):
                    exploits.append(exploit)
        return exploits
    
    # ═══════════════════════════════════════════════════════════════════════════
    # Graph Analysis
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_network_topology(self) -> Dict:
        """Get network topology information"""
        return {
            "hosts": len(self._hosts),
            "ports": len(self._ports),
            "services": len(self._services),
            "vulnerabilities": len(self._vulnerabilities),
            "credentials": len(self._credentials),
            "compromised_hosts": len(self.get_compromised_hosts()),
            "critical_vulns": len([v for v in self._vulnerabilities.values() 
                                   if v.severity == VulnerabilitySeverity.CRITICAL]),
            "graph_density": nx.density(self.graph),
            "connected_components": nx.number_weakly_connected_components(self.graph),
        }
    
    def get_centrality_scores(self) -> Dict[str, float]:
        """Get centrality scores for hosts (identifies key targets)"""
        host_nodes = [n for n, d in self.graph.nodes(data=True) 
                     if d.get('type') == 'host']
        
        if not host_nodes:
            return {}
        
        # Calculate degree centrality
        centrality = nx.degree_centrality(self.graph)
        return {node: score for node, score in centrality.items() 
                if node in host_nodes}
    
    def identify_high_value_targets(self, top_n: int = 5) -> List[Tuple[str, float]]:
        """Identify high-value targets based on centrality and vulnerabilities"""
        scores = {}
        
        for host_id, host in self._hosts.items():
            score = 0.0
            
            # Centrality
            centrality = nx.degree_centrality(self.graph).get(host_id, 0)
            score += centrality * 10
            
            # Vulnerabilities
            for vuln in host.vulnerabilities:
                if vuln.severity == VulnerabilitySeverity.CRITICAL:
                    score += 5
                elif vuln.severity == VulnerabilitySeverity.HIGH:
                    score += 3
                elif vuln.severity == VulnerabilitySeverity.MEDIUM:
                    score += 1
            
            # Credentials
            score += len(host.credentials) * 2
            
            # Compromise status
            if host.compromised:
                score += 10  # Pivot potential
            
            scores[host_id] = score
        
        # Sort by score
        sorted_targets = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return sorted_targets[:top_n]
    
    # ═══════════════════════════════════════════════════════════════════════════
    # Snapshot Methods
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_snapshot(self) -> Dict[str, Any]:
        """Get current world model snapshot"""
        return {
            "hosts": [h.model_dump() for h in self._hosts.values()],
            "ports": [{"id": k, **p.model_dump()} for k, p in self._ports.items()],
            "services": [{"id": k, **s.model_dump()} for k, s in self._services.items()],
            "vulnerabilities": [v.model_dump() for v in self._vulnerabilities.values()],
            "credentials": [c.model_dump() for c in self._credentials.values()],
            "topology": self.get_network_topology(),
            "high_value_targets": self.identify_high_value_targets(),
        }
    
    def export_to_json(self, filepath: str) -> None:
        """Export world model to JSON"""
        snapshot = self.get_snapshot()
        with open(filepath, 'w') as f:
            json.dump(snapshot, f, indent=2, default=str)
        logger.info(f"Exported world model to {filepath}")
    
    def import_from_json(self, filepath: str) -> None:
        """Import world model from JSON"""
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        # Clear existing data
        self.graph.clear()
        self._hosts.clear()
        self._ports.clear()
        self._services.clear()
        self._vulnerabilities.clear()
        self._credentials.clear()
        
        # Import hosts
        for host_data in data.get("hosts", []):
            host = Host(**host_data)
            self.add_host(host)
        
        logger.info(f"Imported world model from {filepath}")


# Example usage
if __name__ == "__main__":
    # Create world model
    wm = WorldModel("./test_world_model.db")
    
    # Add sample data
    host = Host(
        ip="192.168.1.1",
        hostname="router",
        status=HostStatus.UP,
        source_tool="nmap",
    )
    host_id = wm.add_host(host)
    
    port = Port(
        number=80,
        protocol=ServiceProtocol.TCP,
        state=PortState.OPEN,
        service_name="http",
        source_tool="nmap",
    )
    wm.add_port(port, host_id)
    
    # Query
    print(f"Hosts: {len(wm.get_hosts())}")
    print(f"Topology: {wm.get_network_topology()}")
