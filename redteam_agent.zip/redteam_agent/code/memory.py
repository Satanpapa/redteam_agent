"""
Memory Architecture - Two-tier memory system for Red Team Agent
Short-term: LangGraph state + current World Model
Long-term: Vector Store (Chroma/LanceDB) + SQLite for tactics
"""

from __future__ import annotations

import hashlib
import json
import logging
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from models import Action, ExecutionResult, MemoryEntry, TacticPattern

logger = logging.getLogger(__name__)


class VectorStore:
    """
    Abstract base for vector stores
    Supports ChromaDB and LanceDB backends
    """
    
    def __init__(self, backend: str = "chroma", path: str = "./data/vectors"):
        self.backend = backend
        self.path = path
        self._client = None
        self._collection = None
        self._embedding_func = None
        
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._init_backend()
    
    def _init_backend(self) -> None:
        """Initialize the vector store backend"""
        if self.backend == "chroma":
            self._init_chroma()
        elif self.backend == "lancedb":
            self._init_lancedb()
        else:
            raise ValueError(f"Unknown backend: {self.backend}")
    
    def _init_chroma(self) -> None:
        """Initialize ChromaDB"""
        try:
            import chromadb
            from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction
            
            self._client = chromadb.PersistentClient(path=self.path)
            
            # Get or create collection
            self._collection = self._client.get_or_create_collection(
                name="redteam_memories",
                metadata={"hnsw:space": "cosine"}
            )
            
            # Use default embedding function
            self._embedding_func = SentenceTransformerEmbeddingFunction(
                model_name="all-MiniLM-L6-v2"
            )
            
            logger.info("ChromaDB initialized")
            
        except ImportError:
            logger.warning("ChromaDB not installed, using fallback")
            self._init_fallback()
    
    def _init_lancedb(self) -> None:
        """Initialize LanceDB"""
        try:
            import lancedb
            
            self._client = lancedb.connect(self.path)
            
            # Create table if not exists
            try:
                self._collection = self._client.open_table("memories")
            except Exception:
                # Create new table
                import pyarrow as pa
                
                schema = pa.schema([
                    pa.field("id", pa.string()),
                    pa.field("content", pa.string()),
                    pa.field("embedding", pa.list_(pa.float32(), 384)),
                    pa.field("metadata", pa.string()),
                ])
                
                self._collection = self._client.create_table(
                    "memories",
                    schema=schema,
                    mode="overwrite"
                )
            
            logger.info("LanceDB initialized")
            
        except ImportError:
            logger.warning("LanceDB not installed, using fallback")
            self._init_fallback()
    
    def _init_fallback(self) -> None:
        """Initialize simple in-memory fallback"""
        self._memory: Dict[str, Dict] = {}
        self._embedding_func = None
        logger.info("Using in-memory fallback for vector store")
    
    def _get_embedding(self, text: str) -> List[float]:
        """Get embedding for text"""
        if self._embedding_func:
            try:
                embeddings = self._embedding_func([text])
                return embeddings[0].tolist() if hasattr(embeddings[0], 'tolist') else embeddings[0]
            except Exception as e:
                logger.warning(f"Embedding failed: {e}")
        
        # Fallback: simple hash-based embedding
        return self._hash_embedding(text)
    
    def _hash_embedding(self, text: str, dim: int = 384) -> List[float]:
        """Create deterministic embedding from hash"""
        hash_bytes = hashlib.sha256(text.encode()).digest()
        np.random.seed(int.from_bytes(hash_bytes[:4], 'big'))
        embedding = np.random.randn(dim).astype(np.float32)
        # Normalize
        embedding = embedding / np.linalg.norm(embedding)
        return embedding.tolist()
    
    def add(
        self,
        id: str,
        content: str,
        metadata: Optional[Dict] = None
    ) -> None:
        """Add entry to vector store"""
        embedding = self._get_embedding(content)
        
        if self.backend == "chroma" and self._collection is not None:
            self._collection.add(
                ids=[id],
                documents=[content],
                embeddings=[embedding],
                metadatas=[metadata or {}]
            )
        elif self.backend == "lancedb" and self._collection is not None:
            import pyarrow as pa
            
            data = pa.table({
                "id": [id],
                "content": [content],
                "embedding": [embedding],
                "metadata": [json.dumps(metadata or {})],
            })
            self._collection.add(data)
        else:
            # Fallback
            self._memory[id] = {
                "content": content,
                "embedding": embedding,
                "metadata": metadata or {},
            }
    
    def search(
        self,
        query: str,
        top_k: int = 5,
        filter_dict: Optional[Dict] = None
    ) -> List[Tuple[str, float, Dict]]:
        """
        Search vector store
        
        Returns:
            List of (id, score, metadata) tuples
        """
        query_embedding = self._get_embedding(query)
        
        if self.backend == "chroma" and self._collection is not None:
            results = self._collection.query(
                query_embeddings=[query_embedding],
                n_results=top_k,
                where=filter_dict,
                include=["metadatas", "distances"]
            )
            
            return [
                (results["ids"][0][i], 1 - results["distances"][0][i], results["metadatas"][0][i])
                for i in range(len(results["ids"][0]))
            ]
            
        elif self.backend == "lancedb" and self._collection is not None:
            # LanceDB search
            results = self._collection.search(query_embedding).limit(top_k).to_arrow()
            
            return [
                (row["id"], row["_distance"], json.loads(row["metadata"]))
                for row in results.to_pylist()
            ]
        else:
            # Fallback: cosine similarity
            return self._fallback_search(query_embedding, top_k)
    
    def _fallback_search(
        self,
        query_embedding: List[float],
        top_k: int
    ) -> List[Tuple[str, float, Dict]]:
        """Fallback search using cosine similarity"""
        query_vec = np.array(query_embedding)
        
        scores = []
        for id, entry in self._memory.items():
            entry_vec = np.array(entry["embedding"])
            similarity = np.dot(query_vec, entry_vec) / (
                np.linalg.norm(query_vec) * np.linalg.norm(entry_vec)
            )
            scores.append((id, float(similarity), entry["metadata"]))
        
        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:top_k]
    
    def delete(self, id: str) -> None:
        """Delete entry from vector store"""
        if self.backend == "chroma" and self._collection is not None:
            self._collection.delete(ids=[id])
        elif self.backend == "lancedb":
            # LanceDB deletion
            pass
        else:
            self._memory.pop(id, None)


class TacticalMemory:
    """
    SQLite-based tactical memory for storing action patterns and effectiveness
    """
    
    def __init__(self, db_path: str = "./data/tactics.db"):
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_database()
    
    def _init_database(self) -> None:
        """Initialize tactical memory database"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Tactics table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS tactics (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    description TEXT,
                    action_type TEXT NOT NULL,
                    tool_name TEXT NOT NULL,
                    tool_options_pattern TEXT,
                    target_service_pattern TEXT,
                    target_os_pattern TEXT,
                    total_attempts INTEGER DEFAULT 0,
                    successful_attempts INTEGER DEFAULT 0,
                    avg_execution_time REAL,
                    success_rate REAL DEFAULT 0.0,
                    created_at TEXT,
                    last_used TEXT
                )
            """)
            
            # Pattern executions table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS pattern_executions (
                    id TEXT PRIMARY KEY,
                    tactic_id TEXT NOT NULL,
                    context_hash TEXT,
                    success INTEGER DEFAULT 0,
                    execution_time_ms INTEGER,
                    discovered_entities TEXT,
                    executed_at TEXT,
                    FOREIGN KEY (tactic_id) REFERENCES tactics(id)
                )
            """)
            
            # Indexes
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_tactics_tool ON tactics(tool_name)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_tactics_success ON tactics(success_rate)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_executions_tactic ON pattern_executions(tactic_id)")
            
            conn.commit()
            logger.info("Tactical memory database initialized")
    
    def store_tactic(self, tactic: TacticPattern) -> str:
        """Store or update a tactic pattern"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO tactics 
                (id, name, description, action_type, tool_name, tool_options_pattern,
                 target_service_pattern, target_os_pattern, total_attempts, successful_attempts,
                 avg_execution_time, success_rate, created_at, last_used)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                tactic.id, tactic.name, tactic.description, tactic.action_type.value,
                tactic.tool_name, json.dumps(tactic.tool_options_pattern),
                tactic.target_service_pattern, tactic.target_os_pattern,
                tactic.total_attempts, tactic.successful_attempts,
                tactic.avg_execution_time, tactic.success_rate,
                tactic.created_at.isoformat(),
                tactic.last_used.isoformat() if tactic.last_used else None
            ))
            conn.commit()
        return tactic.id
    
    def get_tactic(self, tactic_id: str) -> Optional[TacticPattern]:
        """Get tactic by ID"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM tactics WHERE id = ?", (tactic_id,))
            row = cursor.fetchone()
            
            if row:
                return self._row_to_tactic(row)
        return None
    
    def find_tactics(
        self,
        tool_name: Optional[str] = None,
        action_type: Optional[str] = None,
        min_success_rate: float = 0.0,
        limit: int = 10
    ) -> List[TacticPattern]:
        """Find tactics matching criteria"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            query = "SELECT * FROM tactics WHERE success_rate >= ?"
            params = [min_success_rate]
            
            if tool_name:
                query += " AND tool_name = ?"
                params.append(tool_name)
            
            if action_type:
                query += " AND action_type = ?"
                params.append(action_type)
            
            query += " ORDER BY success_rate DESC LIMIT ?"
            params.append(limit)
            
            cursor.execute(query, params)
            return [self._row_to_tactic(row) for row in cursor.fetchall()]
    
    def _row_to_tactic(self, row: sqlite3.Row) -> TacticPattern:
        """Convert database row to TacticPattern"""
        return TacticPattern(
            id=row['id'],
            name=row['name'],
            description=row['description'],
            action_type=row['action_type'],
            tool_name=row['tool_name'],
            tool_options_pattern=json.loads(row['tool_options_pattern']) if row['tool_options_pattern'] else {},
            target_service_pattern=row['target_service_pattern'],
            target_os_pattern=row['target_os_pattern'],
            total_attempts=row['total_attempts'],
            successful_attempts=row['successful_attempts'],
            avg_execution_time=row['avg_execution_time'],
            success_rate=row['success_rate'],
            created_at=datetime.fromisoformat(row['created_at']),
            last_used=datetime.fromisoformat(row['last_used']) if row['last_used'] else None,
        )
    
    def record_execution(
        self,
        tactic_id: str,
        success: bool,
        context_hash: str,
        execution_time_ms: Optional[int] = None,
        discovered_entities: Optional[Dict] = None
    ) -> None:
        """Record an execution of a tactic"""
        import uuid
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Add execution record
            cursor.execute("""
                INSERT INTO pattern_executions 
                (id, tactic_id, context_hash, success, execution_time_ms, discovered_entities, executed_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                str(uuid.uuid4()), tactic_id, context_hash, int(success),
                execution_time_ms, json.dumps(discovered_entities or {}),
                datetime.utcnow().isoformat()
            ))
            
            # Update tactic stats
            cursor.execute("""
                UPDATE tactics 
                SET total_attempts = total_attempts + 1,
                    successful_attempts = successful_attempts + ?,
                    last_used = ?
                WHERE id = ?
            """, (int(success), datetime.utcnow().isoformat(), tactic_id))
            
            # Recalculate success rate
            cursor.execute("""
                UPDATE tactics 
                SET success_rate = CAST(successful_attempts AS REAL) / total_attempts
                WHERE id = ?
            """, (tactic_id,))
            
            conn.commit()
    
    def update_tactic_score(self, tool_name: str, success: bool) -> List[str]:
        """Update tactic score for a tool"""
        tactics = self.find_tactics(tool_name=tool_name)
        updated = []
        
        for tactic in tactics:
            tactic.total_attempts += 1
            if success:
                tactic.successful_attempts += 1
            tactic.success_rate = tactic.successful_attempts / tactic.total_attempts
            tactic.last_used = datetime.utcnow()
            
            self.store_tactic(tactic)
            updated.append(tactic.id)
        
        return updated


class MemorySystem:
    """
    Unified memory system combining vector store and tactical memory
    """
    
    def __init__(
        self,
        vector_store_path: str = "./data/vectors",
        tactical_db_path: str = "./data/tactics.db",
        vector_backend: str = "chroma"
    ):
        self.vector_store = VectorStore(
            backend=vector_backend,
            path=vector_store_path
        )
        self.tactical_memory = TacticalMemory(db_path=tactical_db_path)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # Vector Store Operations
    # ═══════════════════════════════════════════════════════════════════════════
    
    def store_pattern(
        self,
        action: Action,
        context: Dict[str, Any],
        result: ExecutionResult
    ) -> str:
        """
        Store a successful pattern in memory
        
        Args:
            action: The action that was executed
            context: World model context
            result: Execution result
            
        Returns:
            Pattern ID
        """
        import uuid
        
        pattern_id = str(uuid.uuid4())
        
        # Create description
        description = f"""
        Tool: {action.tool_name}
        Command: {action.tool_command}
        Target: {action.target_host_id or 'unknown'}
        Result: {'Success' if result.success else 'Failure'}
        Discovered: {len(result.new_hosts)} hosts, {len(result.new_vulnerabilities)} vulns
        """
        
        # Store in vector store
        metadata = {
            "action_id": action.id,
            "tool_name": action.tool_name,
            "action_type": action.action_type.value if hasattr(action.action_type, 'value') else str(action.action_type),
            "success": result.success,
            "hosts_discovered": len(result.new_hosts),
            "vulns_discovered": len(result.new_vulnerabilities),
        }
        
        self.vector_store.add(pattern_id, description.strip(), metadata)
        
        # Also store in tactical memory
        tactic = TacticPattern(
            id=pattern_id,
            name=action.name,
            description=description.strip(),
            action_type=action.action_type,
            tool_name=action.tool_name,
            tool_options_pattern=action.tool_options,
            target_service_pattern=action.target_service,
        )
        
        if result.success:
            tactic.successful_attempts = 1
        tactic.total_attempts = 1
        tactic.success_rate = 1.0 if result.success else 0.0
        
        self.tactical_memory.store_tactic(tactic)
        
        logger.info(f"Stored pattern: {pattern_id}")
        return pattern_id
    
    def get_relevant_memories(
        self,
        context_hash: str,
        query: Optional[str] = None,
        top_k: int = 5
    ) -> List[Dict]:
        """
        Get memories relevant to current context
        
        Args:
            context_hash: Hash of current context
            query: Optional query string
            top_k: Number of memories to return
            
        Returns:
            List of relevant memories
        """
        if query:
            results = self.vector_store.search(query, top_k=top_k)
        else:
            # Search by context hash similarity
            results = self.vector_store.search(context_hash, top_k=top_k)
        
        memories = []
        for id, score, metadata in results:
            memories.append({
                "id": id,
                "relevance_score": score,
                **metadata
            })
        
        return memories
    
    # ═══════════════════════════════════════════════════════════════════════════
    # Tactical Memory Operations
    # ═══════════════════════════════════════════════════════════════════════════
    
    def get_effective_tactics(
        self,
        tool_name: Optional[str] = None,
        min_success_rate: float = 0.5,
        limit: int = 10
    ) -> List[TacticPattern]:
        """Get tactics with proven effectiveness"""
        return self.tactical_memory.find_tactics(
            tool_name=tool_name,
            min_success_rate=min_success_rate,
            limit=limit
        )
    
    def update_tactic_score(self, tool_name: str, success: bool) -> List[str]:
        """Update tactic effectiveness score"""
        return self.tactical_memory.update_tactic_score(tool_name, success)
    
    def record_execution(
        self,
        tactic_id: str,
        success: bool,
        context_hash: str,
        execution_time_ms: Optional[int] = None
    ) -> None:
        """Record tactic execution"""
        self.tactical_memory.record_execution(
            tactic_id=tactic_id,
            success=success,
            context_hash=context_hash,
            execution_time_ms=execution_time_ms
        )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # Context Hashing
    # ═══════════════════════════════════════════════════════════════════════════
    
    @staticmethod
    def hash_context(context: Dict[str, Any]) -> str:
        """Create hash of context for memory lookup"""
        context_str = json.dumps(context, sort_keys=True, default=str)
        return hashlib.sha256(context_str.encode()).hexdigest()[:16]


# Example usage
if __name__ == "__main__":
    # Create memory system
    memory = MemorySystem(
        vector_store_path="./test_vectors",
        tactical_db_path="./test_tactics.db",
        vector_backend="fallback"  # Use fallback for testing
    )
    
    # Store a pattern
    action = Action(
        name="test_scan",
        action_type="scan",
        tool_name="nmap",
        tool_command="nmap -sV target",
    )
    
    result = ExecutionResult(
        action_id=action.id,
        success=True,
    )
    
    pattern_id = memory.store_pattern(
        action=action,
        context={"hosts": [], "phase": "recon"},
        result=result
    )
    
    print(f"Stored pattern: {pattern_id}")
    
    # Retrieve memories
    memories = memory.get_relevant_memories("test_context", query="nmap scan")
    print(f"Found {len(memories)} relevant memories")
