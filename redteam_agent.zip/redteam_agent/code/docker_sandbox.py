"""
Docker Sandbox Manager - Secure execution environment for security tools
Manages container lifecycle, resource limits, snapshots, and network isolation
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import tarfile
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

import docker
from docker.errors import DockerException, NotFound
from docker.models.containers import Container

from models import ToolOutput

# Setup logging
logger = logging.getLogger(__name__)


@dataclass
class SandboxConfig:
    """Configuration for Docker sandbox"""
    
    # Image settings
    image: str = "kalilinux/kali-rolling:latest"
    pull_policy: str = "if_not_present"  # always, if_not_present, never
    
    # Resource limits
    cpu_limit: float = 2.0
    memory_limit: str = "4g"
    memory_swap: str = "4g"  # Same as memory to disable swap
    
    # Network settings
    network_mode: str = "bridge"  # bridge, host, none, or custom network
    dns_servers: List[str] = field(default_factory=lambda: ["8.8.8.8", "1.1.1.1"])
    
    # Volume mounts
    tools_path: str = "./tools"
    workspace_path: str = "./workspace"
    data_path: str = "./data"
    
    # Security
    capabilities: List[str] = field(default_factory=lambda: ["NET_ADMIN"])
    read_only_root: bool = False
    no_new_privileges: bool = True
    
    # Snapshot settings
    enable_snapshots: bool = True
    snapshot_dir: str = "./snapshots"
    
    # Execution settings
    default_timeout: int = 300  # seconds
    max_output_size: int = 10 * 1024 * 1024  # 10 MB


@dataclass
class ExecutionConfig:
    """Configuration for a single command execution"""
    
    command: str
    working_dir: str = "/workspace"
    timeout: Optional[int] = None
    env_vars: Dict[str, str] = field(default_factory=dict)
    input_data: Optional[str] = None
    capture_output: bool = True
    
    def __post_init__(self):
        if self.timeout is None:
            self.timeout = 300  # Default 5 minutes


class SandboxSnapshot:
    """Represents a container snapshot"""
    
    def __init__(
        self,
        snapshot_id: str,
        container_id: str,
        created_at: datetime,
        description: Optional[str] = None,
        metadata: Optional[Dict] = None
    ):
        self.snapshot_id = snapshot_id
        self.container_id = container_id
        self.created_at = created_at
        self.description = description or ""
        self.metadata = metadata or {}
    
    def to_dict(self) -> Dict:
        return {
            "snapshot_id": self.snapshot_id,
            "container_id": self.container_id,
            "created_at": self.created_at.isoformat(),
            "description": self.description,
            "metadata": self.metadata,
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> "SandboxSnapshot":
        return cls(
            snapshot_id=data["snapshot_id"],
            container_id=data["container_id"],
            created_at=datetime.fromisoformat(data["created_at"]),
            description=data.get("description"),
            metadata=data.get("metadata", {}),
        )


class DockerSandboxManager:
    """
    Manages Docker containers for secure tool execution
    
    Features:
    - Container lifecycle management (create, start, stop, remove)
    - Resource limits (CPU, memory)
    - Network isolation
    - Snapshot/restore functionality
    - Volume management
    - Execution monitoring
    """
    
    def __init__(self, config: Optional[SandboxConfig] = None):
        """
        Initialize Docker Sandbox Manager
        
        Args:
            config: Sandbox configuration
        """
        self.config = config or SandboxConfig()
        
        # Initialize Docker client
        try:
            self.client = docker.from_env()
            logger.info("Docker client initialized successfully")
        except DockerException as e:
            logger.error(f"Failed to initialize Docker client: {e}")
            raise RuntimeError(f"Docker is not available: {e}")
        
        # Track active containers
        self._containers: Dict[str, Container] = {}
        self._snapshots: Dict[str, SandboxSnapshot] = {}
        
        # Ensure directories exist
        Path(self.config.workspace_path).mkdir(parents=True, exist_ok=True)
        Path(self.config.snapshot_dir).mkdir(parents=True, exist_ok=True)
        
        # Load existing snapshots
        self._load_snapshots()
    
    def _load_snapshots(self) -> None:
        """Load snapshot metadata from disk"""
        snapshot_file = Path(self.config.snapshot_dir) / "snapshots.json"
        if snapshot_file.exists():
            try:
                with open(snapshot_file, "r") as f:
                    data = json.load(f)
                    for snap_data in data:
                        snapshot = SandboxSnapshot.from_dict(snap_data)
                        self._snapshots[snapshot.snapshot_id] = snapshot
                logger.info(f"Loaded {len(self._snapshots)} snapshots")
            except Exception as e:
                logger.warning(f"Failed to load snapshots: {e}")
    
    def _save_snapshots(self) -> None:
        """Save snapshot metadata to disk"""
        snapshot_file = Path(self.config.snapshot_dir) / "snapshots.json"
        try:
            data = [snap.to_dict() for snap in self._snapshots.values()]
            with open(snapshot_file, "w") as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.warning(f"Failed to save snapshots: {e}")
    
    def _ensure_image(self) -> None:
        """Ensure the required Docker image is available"""
        try:
            self.client.images.get(self.config.image)
            logger.debug(f"Image {self.config.image} is available")
        except NotFound:
            if self.config.pull_policy in ["always", "if_not_present"]:
                logger.info(f"Pulling image {self.config.image}...")
                self.client.images.pull(self.config.image)
                logger.info(f"Image {self.config.image} pulled successfully")
            else:
                raise RuntimeError(f"Image {self.config.image} not found and pull_policy is {self.config.pull_policy}")
    
    def create_container(
        self,
        name: Optional[str] = None,
        network: Optional[str] = None,
        labels: Optional[Dict[str, str]] = None
    ) -> str:
        """
        Create a new sandbox container
        
        Args:
            name: Container name (auto-generated if None)
            network: Network to connect to
            labels: Container labels
            
        Returns:
            Container ID
        """
        self._ensure_image()
        
        # Generate name if not provided
        if name is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            name = f"redteam-sandbox-{timestamp}"
        
        # Prepare volumes
        volumes = {
            os.path.abspath(self.config.workspace_path): {
                "bind": "/workspace",
                "mode": "rw",
            },
        }
        
        if os.path.exists(self.config.tools_path):
            volumes[os.path.abspath(self.config.tools_path)] = {
                "bind": "/opt/tools",
                "mode": "ro",
            }
        
        if os.path.exists(self.config.data_path):
            volumes[os.path.abspath(self.config.data_path)] = {
                "bind": "/data",
                "mode": "ro",
            }
        
        # Prepare labels
        container_labels = {
            "app": "redteam-sandbox",
            "created": datetime.now().isoformat(),
        }
        if labels:
            container_labels.update(labels)
        
        # Create container
        try:
            container = self.client.containers.create(
                image=self.config.image,
                name=name,
                command="sleep infinity",  # Keep container running
                volumes=volumes,
                network=network or self.config.network_mode,
                dns=self.config.dns_servers,
                cap_add=self.config.capabilities,
                cpu_quota=int(self.config.cpu_limit * 100000),
                mem_limit=self.config.memory_limit,
                memswap_limit=self.config.memory_swap,
                read_only=self.config.read_only_root,
                security_opt=[f"no-new-privileges:{str(self.config.no_new_privileges).lower()}"],
                labels=container_labels,
                stdin_open=True,
                tty=True,
                detach=True,
            )
            
            self._containers[container.id] = container
            logger.info(f"Created container {container.id[:12]} ({name})")
            
            return container.id
            
        except DockerException as e:
            logger.error(f"Failed to create container: {e}")
            raise
    
    def start_container(self, container_id: str) -> None:
        """Start a container"""
        container = self._get_container(container_id)
        if container.status != "running":
            container.start()
            logger.info(f"Started container {container_id[:12]}")
    
    def stop_container(
        self,
        container_id: str,
        timeout: int = 30
    ) -> None:
        """Stop a container gracefully"""
        container = self._get_container(container_id)
        if container.status == "running":
            container.stop(timeout=timeout)
            logger.info(f"Stopped container {container_id[:12]}")
    
    def remove_container(
        self,
        container_id: str,
        force: bool = False
    ) -> None:
        """Remove a container"""
        container = self._get_container(container_id)
        container.remove(force=force)
        
        if container_id in self._containers:
            del self._containers[container_id]
        
        logger.info(f"Removed container {container_id[:12]}")
    
    def _get_container(self, container_id: str) -> Container:
        """Get container by ID (from cache or Docker)"""
        if container_id in self._containers:
            # Refresh container info
            self._containers[container_id].reload()
            return self._containers[container_id]
        
        # Get from Docker
        try:
            container = self.client.containers.get(container_id)
            self._containers[container_id] = container
            return container
        except NotFound:
            raise ValueError(f"Container {container_id} not found")
    
    def execute(
        self,
        container_id: str,
        config: ExecutionConfig
    ) -> ToolOutput:
        """
        Execute a command in the sandbox
        
        Args:
            container_id: Container ID
            config: Execution configuration
            
        Returns:
            ToolOutput with results
        """
        container = self._get_container(container_id)
        
        # Ensure container is running
        if container.status != "running":
            logger.info(f"Starting container {container_id[:12]}")
            container.start()
            time.sleep(1)  # Give container time to initialize
        
        # Prepare environment
        env = config.env_vars.copy()
        env["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/opt/tools"
        
        start_time = time.time()
        
        try:
            logger.debug(f"Executing: {config.command}")
            
            # Execute command
            exec_result = container.exec_run(
                cmd=["sh", "-c", config.command],
                workdir=config.working_dir,
                environment=env,
                stdin=config.input_data is not None,
                demux=True,
            )
            
            execution_time = int((time.time() - start_time) * 1000)
            
            # Parse output
            stdout_bytes, stderr_bytes = exec_result.output or (b"", b"")
            stdout = stdout_bytes.decode("utf-8", errors="replace") if stdout_bytes else ""
            stderr = stderr_bytes.decode("utf-8", errors="replace") if stderr_bytes else ""
            
            # Truncate if too large
            if len(stdout) > self.config.max_output_size:
                stdout = stdout[:self.config.max_output_size] + "\n... [truncated]"
            
            logger.debug(f"Command completed in {execution_time}ms with exit code {exec_result.exit_code}")
            
            return ToolOutput(
                tool_name="sandbox",
                command=config.command,
                exit_code=exec_result.exit_code,
                stdout=stdout,
                stderr=stderr,
                execution_time_ms=execution_time,
                sandbox_id=container_id,
            )
            
        except Exception as e:
            logger.error(f"Execution failed: {e}")
            return ToolOutput(
                tool_name="sandbox",
                command=config.command,
                exit_code=-1,
                stdout="",
                stderr=str(e),
                execution_time_ms=int((time.time() - start_time) * 1000),
                sandbox_id=container_id,
            )
    
    def execute_tool(
        self,
        container_id: str,
        tool_name: str,
        tool_args: str,
        timeout: Optional[int] = None,
        env_vars: Optional[Dict[str, str]] = None
    ) -> ToolOutput:
        """
        Convenience method to execute a security tool
        
        Args:
            container_id: Container ID
            tool_name: Tool name (nmap, gobuster, etc.)
            tool_args: Tool arguments
            timeout: Execution timeout
            env_vars: Additional environment variables
            
        Returns:
            ToolOutput with results
        """
        command = f"{tool_name} {tool_args}"
        
        config = ExecutionConfig(
            command=command,
            timeout=timeout or self.config.default_timeout,
            env_vars=env_vars or {},
        )
        
        return self.execute(container_id, config)
    
    def create_snapshot(
        self,
        container_id: str,
        description: Optional[str] = None
    ) -> str:
        """
        Create a snapshot of container state
        
        Args:
            container_id: Container ID
            description: Snapshot description
            
        Returns:
            Snapshot ID
        """
        if not self.config.enable_snapshots:
            raise RuntimeError("Snapshots are disabled")
        
        container = self._get_container(container_id)
        
        # Generate snapshot ID
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        snapshot_id = f"snap_{container_id[:12]}_{timestamp}"
        
        # Commit container to new image
        try:
            image = container.commit(
                repository="redteam-sandbox-snapshots",
                tag=snapshot_id,
                message=description or f"Snapshot {snapshot_id}",
            )
            
            # Save snapshot metadata
            snapshot = SandboxSnapshot(
                snapshot_id=snapshot_id,
                container_id=container_id,
                created_at=datetime.now(),
                description=description,
                metadata={
                    "image_id": image.id,
                    "container_status": container.status,
                },
            )
            
            self._snapshots[snapshot_id] = snapshot
            self._save_snapshots()
            
            logger.info(f"Created snapshot {snapshot_id}")
            return snapshot_id
            
        except DockerException as e:
            logger.error(f"Failed to create snapshot: {e}")
            raise
    
    def restore_snapshot(self, snapshot_id: str, new_name: Optional[str] = None) -> str:
        """
        Restore container from snapshot
        
        Args:
            snapshot_id: Snapshot ID
            new_name: Name for new container
            
        Returns:
            New container ID
        """
        if snapshot_id not in self._snapshots:
            raise ValueError(f"Snapshot {snapshot_id} not found")
        
        snapshot = self._snapshots[snapshot_id]
        image_tag = f"redteam-sandbox-snapshots:{snapshot_id}"
        
        try:
            # Create new container from snapshot image
            container_id = self.create_container(
                name=new_name,
                labels={"restored_from": snapshot_id}
            )
            
            logger.info(f"Restored snapshot {snapshot_id} to container {container_id[:12]}")
            return container_id
            
        except DockerException as e:
            logger.error(f"Failed to restore snapshot: {e}")
            raise
    
    def list_snapshots(self, container_id: Optional[str] = None) -> List[SandboxSnapshot]:
        """List available snapshots"""
        snapshots = list(self._snapshots.values())
        
        if container_id:
            snapshots = [s for s in snapshots if s.container_id == container_id]
        
        return sorted(snapshots, key=lambda s: s.created_at, reverse=True)
    
    def delete_snapshot(self, snapshot_id: str) -> None:
        """Delete a snapshot"""
        if snapshot_id not in self._snapshots:
            raise ValueError(f"Snapshot {snapshot_id} not found")
        
        try:
            # Remove image
            image_tag = f"redteam-sandbox-snapshots:{snapshot_id}"
            self.client.images.remove(image_tag, force=True)
            
            # Remove metadata
            del self._snapshots[snapshot_id]
            self._save_snapshots()
            
            logger.info(f"Deleted snapshot {snapshot_id}")
            
        except DockerException as e:
            logger.warning(f"Failed to delete snapshot image: {e}")
    
    def get_container_stats(self, container_id: str) -> Dict:
        """Get container resource usage statistics"""
        container = self._get_container(container_id)
        
        try:
            stats = container.stats(stream=False)
            
            # Calculate CPU usage
            cpu_delta = (
                stats["cpu_stats"]["cpu_usage"]["total_usage"] -
                stats["precpu_stats"]["cpu_usage"]["total_usage"]
            )
            system_delta = (
                stats["cpu_stats"]["system_cpu_usage"] -
                stats["precpu_stats"]["system_cpu_usage"]
            )
            
            cpu_percent = 0.0
            if system_delta > 0:
                cpu_percent = (cpu_delta / system_delta) * 100.0
            
            # Memory usage
            memory_usage = stats["memory_stats"].get("usage", 0)
            memory_limit = stats["memory_stats"].get("limit", 1)
            memory_percent = (memory_usage / memory_limit) * 100.0
            
            return {
                "cpu_percent": round(cpu_percent, 2),
                "memory_usage": memory_usage,
                "memory_limit": memory_limit,
                "memory_percent": round(memory_percent, 2),
                "network_rx": stats["networks"]["eth0"]["rx_bytes"] if "networks" in stats else 0,
                "network_tx": stats["networks"]["eth0"]["tx_bytes"] if "networks" in stats else 0,
            }
            
        except Exception as e:
            logger.warning(f"Failed to get container stats: {e}")
            return {}
    
    def list_containers(
        self,
        all_containers: bool = False
    ) -> List[Dict]:
        """List managed containers"""
        containers = []
        
        for container_id in list(self._containers.keys()):
            try:
                container = self._get_container(container_id)
                
                if not all_containers and container.status != "running":
                    continue
                
                containers.append({
                    "id": container.id,
                    "short_id": container.short_id,
                    "name": container.name,
                    "status": container.status,
                    "image": container.image.tags[0] if container.image.tags else "unknown",
                    "created": container.attrs["Created"],
                    "labels": container.labels,
                })
                
            except Exception as e:
                logger.warning(f"Failed to get container info: {e}")
        
        return containers
    
    def cleanup(self, remove_all: bool = False) -> None:
        """
        Cleanup containers
        
        Args:
            remove_all: Remove all containers, not just stopped ones
        """
        for container_id in list(self._containers.keys()):
            try:
                container = self._get_container(container_id)
                
                if remove_all or container.status != "running":
                    self.remove_container(container_id, force=True)
                    
            except Exception as e:
                logger.warning(f"Failed to cleanup container: {e}")
        
        logger.info("Cleanup completed")
    
    def __enter__(self):
        """Context manager entry"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - cleanup resources"""
        self.cleanup(remove_all=False)


# Convenience functions

def create_sandbox(config: Optional[SandboxConfig] = None) -> DockerSandboxManager:
    """Factory function to create sandbox manager"""
    return DockerSandboxManager(config)


def quick_execute(
    command: str,
    timeout: int = 300,
    image: str = "kalilinux/kali-rolling:latest"
) -> ToolOutput:
    """
    Quick one-off command execution (creates and removes container)
    
    Args:
        command: Command to execute
        timeout: Execution timeout
        image: Docker image to use
        
    Returns:
        ToolOutput with results
    """
    config = SandboxConfig(image=image)
    
    with DockerSandboxManager(config) as manager:
        container_id = manager.create_container()
        manager.start_container(container_id)
        
        exec_config = ExecutionConfig(command=command, timeout=timeout)
        result = manager.execute(container_id, exec_config)
        
        return result


# Example usage
if __name__ == "__main__":
    # Test sandbox manager
    config = SandboxConfig(
        memory_limit="2g",
        cpu_limit=1.0,
    )
    
    with DockerSandboxManager(config) as manager:
        # Create and start container
        container_id = manager.create_container()
        manager.start_container(container_id)
        
        print(f"Created container: {container_id[:12]}")
        
        # Execute a simple command
        result = manager.execute_tool(
            container_id=container_id,
            tool_name="echo",
            tool_args='"Hello from sandbox!"',
        )
        
        print(f"\nExit code: {result.exit_code}")
        print(f"Output: {result.stdout}")
        print(f"Execution time: {result.execution_time_ms}ms")
        
        # Get container stats
        stats = manager.get_container_stats(container_id)
        print(f"\nContainer stats: {stats}")
        
        # Cleanup happens automatically on context exit
