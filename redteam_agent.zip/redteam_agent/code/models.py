"""
Data Models for Red Team Agent
Pydantic v2 models for structured data throughout the system
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum, StrEnum
from typing import Any, Dict, List, Optional, Set, Union
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field, field_validator


# ═══════════════════════════════════════════════════════════════════════════════
# Enums
# ═══════════════════════════════════════════════════════════════════════════════

class HostStatus(StrEnum):
    """Status of a host in the network"""
    UNKNOWN = "unknown"
    UP = "up"
    DOWN = "down"
    FIREWALLED = "firewalled"


class PortState(StrEnum):
    """State of a network port"""
    OPEN = "open"
    CLOSED = "closed"
    FILTERED = "filtered"
    UNFILTERED = "unfiltered"
    OPEN_FILTERED = "open|filtered"
    CLOSED_FILTERED = "closed|filtered"


class ServiceProtocol(StrEnum):
    """Transport protocol"""
    TCP = "tcp"
    UDP = "udp"
    SCTP = "sctp"


class VulnerabilitySeverity(StrEnum):
    """CVSS severity levels"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class ExploitType(StrEnum):
    """Types of exploits"""
    REMOTE = "remote"
    LOCAL = "local"
    CLIENT_SIDE = "client_side"
    WEB = "web"
    PRIVILEGE_ESCALATION = "privilege_escalation"


class ExploitStatus(StrEnum):
    """Status of exploit execution"""
    NOT_ATTEMPTED = "not_attempted"
    ATTEMPTED = "attempted"
    SUCCESSFUL = "successful"
    FAILED = "failed"
    BLOCKED = "blocked"


class ActionType(StrEnum):
    """Types of actions the agent can take"""
    RECON = "recon"
    SCAN = "scan"
    ENUMERATE = "enumerate"
    EXPLOIT = "exploit"
    POST_EXPLOIT = "post_exploit"
    PIVOT = "pivot"
    CREDENTIAL_ATTACK = "credential_attack"


class ActionStatus(StrEnum):
    """Status of action execution"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class Phase(StrEnum):
    """Phases of the attack lifecycle"""
    RECONNAISSANCE = "reconnaissance"
    WEAPONIZATION = "weaponization"
    DELIVERY = "delivery"
    EXPLOITATION = "exploitation"
    INSTALLATION = "installation"
    COMMAND_CONTROL = "command_control"
    ACTIONS_ON_OBJECTIVES = "actions_on_objectives"


# ═══════════════════════════════════════════════════════════════════════════════
# Network Models
# ═══════════════════════════════════════════════════════════════════════════════

class Port(BaseModel):
    """Represents a network port"""
    model_config = ConfigDict(frozen=False)
    
    number: int = Field(..., ge=1, le=65535)
    protocol: ServiceProtocol = ServiceProtocol.TCP
    state: PortState = PortState.CLOSED
    service_name: Optional[str] = None
    service_version: Optional[str] = None
    banner: Optional[str] = None
    
    # Metadata
    discovered_at: datetime = Field(default_factory=datetime.utcnow)
    source_tool: Optional[str] = None
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    
    def __hash__(self):
        return hash((self.number, self.protocol))
    
    def __eq__(self, other):
        if isinstance(other, Port):
            return self.number == other.number and self.protocol == other.protocol
        return False


class Service(BaseModel):
    """Represents a service running on a port"""
    model_config = ConfigDict(frozen=False)
    
    name: str
    version: Optional[str] = None
    product: Optional[str] = None
    extra_info: Optional[str] = None
    os_type: Optional[str] = None
    
    # HTTP-specific fields
    http_title: Optional[str] = None
    http_methods: List[str] = Field(default_factory=list)
    web_technologies: List[str] = Field(default_factory=list)
    
    # Metadata
    cpe: List[str] = Field(default_factory=list)  # Common Platform Enumeration
    discovered_at: datetime = Field(default_factory=datetime.utcnow)


class Vulnerability(BaseModel):
    """Represents a vulnerability"""
    model_config = ConfigDict(frozen=False)
    
    id: str = Field(default_factory=lambda: str(uuid4()))
    cve_id: Optional[str] = None
    name: str
    description: Optional[str] = None
    severity: VulnerabilitySeverity = VulnerabilitySeverity.INFO
    cvss_score: Optional[float] = Field(None, ge=0.0, le=10.0)
    
    # Affected service
    affected_service: Optional[str] = None
    affected_versions: List[str] = Field(default_factory=list)
    
    # Exploitation info
    exploit_available: bool = False
    exploit_ids: List[str] = Field(default_factory=list)  # EDB-ID, MSF module, etc.
    
    # Metadata
    discovered_at: datetime = Field(default_factory=datetime.utcnow)
    verified: bool = False
    false_positive: bool = False
    notes: Optional[str] = None


class Exploit(BaseModel):
    """Represents an exploit"""
    model_config = ConfigDict(frozen=False)
    
    id: str = Field(default_factory=lambda: str(uuid4()))
    name: str
    exploit_type: ExploitType
    
    # Target info
    targets_cve: List[str] = Field(default_factory=list)
    targets_services: List[str] = Field(default_factory=list)
    
    # Implementation
    module_path: Optional[str] = None  # Path to exploit code
    msf_module: Optional[str] = None  # Metasploit module name
    edb_id: Optional[str] = None  # Exploit-DB ID
    
    # Execution info
    payload_compatible: List[str] = Field(default_factory=list)
    required_options: Dict[str, Any] = Field(default_factory=dict)
    
    # Historical performance
    success_rate: float = Field(default=0.0, ge=0.0, le=1.0)
    execution_count: int = Field(default=0, ge=0)
    last_executed: Optional[datetime] = None
    
    # Metadata
    description: Optional[str] = None
    author: Optional[str] = None
    disclosed_date: Optional[datetime] = None


class Credential(BaseModel):
    """Represents discovered credentials"""
    model_config = ConfigDict(frozen=False)
    
    id: str = Field(default_factory=lambda: str(uuid4()))
    username: Optional[str] = None
    password: Optional[str] = None
    hash_value: Optional[str] = None  # NTLM, bcrypt, etc.
    hash_type: Optional[str] = None
    
    # Context
    service: Optional[str] = None
    host_id: Optional[str] = None
    source: Optional[str] = None  # How it was discovered
    
    # Validation
    validated: bool = False
    validation_method: Optional[str] = None
    
    # Metadata
    discovered_at: datetime = Field(default_factory=datetime.utcnow)


class Host(BaseModel):
    """Represents a target host"""
    model_config = ConfigDict(frozen=False)
    
    id: str = Field(default_factory=lambda: str(uuid4()))
    ip: str
    hostname: Optional[str] = None
    mac_address: Optional[str] = None
    
    # Network info
    subnet: Optional[str] = None
    gateway: Optional[str] = None
    dns_servers: List[str] = Field(default_factory=list)
    
    # OS detection
    os_name: Optional[str] = None
    os_version: Optional[str] = None
    os_family: Optional[str] = None  # Windows, Linux, etc.
    os_accuracy: int = Field(default=0, ge=0, le=100)
    
    # Status
    status: HostStatus = HostStatus.UNKNOWN
    
    # Relationships
    ports: Dict[str, Port] = Field(default_factory=dict)  # key: "tcp/80"
    services: Dict[str, Service] = Field(default_factory=dict)
    vulnerabilities: List[Vulnerability] = Field(default_factory=list)
    credentials: List[Credential] = Field(default_factory=list)
    
    # Compromise status
    compromised: bool = False
    compromise_method: Optional[str] = None
    compromise_time: Optional[datetime] = None
    access_level: Optional[str] = None  # user, admin, system
    
    # Metadata
    discovered_at: datetime = Field(default_factory=datetime.utcnow)
    last_seen: datetime = Field(default_factory=datetime.utcnow)
    source_tool: Optional[str] = None
    tags: Set[str] = Field(default_factory=set)
    notes: Optional[str] = None
    
    @field_validator('ip')
    @classmethod
    def validate_ip(cls, v: str) -> str:
        """Basic IP validation"""
        parts = v.split('.')
        if len(parts) != 4:
            raise ValueError('Invalid IP address format')
        for part in parts:
            if not part.isdigit() or not 0 <= int(part) <= 255:
                raise ValueError('Invalid IP address format')
        return v
    
    def add_port(self, port: Port) -> None:
        """Add or update a port"""
        key = f"{port.protocol}/{port.number}"
        self.ports[key] = port
        self.last_seen = datetime.utcnow()
    
    def get_open_ports(self) -> List[Port]:
        """Get all open ports"""
        return [p for p in self.ports.values() if p.state == PortState.OPEN]


class NetworkSegment(BaseModel):
    """Represents a network segment/subnet"""
    model_config = ConfigDict(frozen=False)
    
    id: str = Field(default_factory=lambda: str(uuid4()))
    cidr: str
    name: Optional[str] = None
    description: Optional[str] = None
    
    # Hosts in this segment
    host_ids: List[str] = Field(default_factory=list)
    
    # Metadata
    discovered_at: datetime = Field(default_factory=datetime.utcnow)


# ═══════════════════════════════════════════════════════════════════════════════
# Action Models
# ═══════════════════════════════════════════════════════════════════════════════

class Action(BaseModel):
    """Represents a potential or executed action"""
    model_config = ConfigDict(frozen=False)
    
    id: str = Field(default_factory=lambda: str(uuid4()))
    action_type: ActionType
    name: str
    description: Optional[str] = None
    phase: Phase
    
    # Target
    target_host_id: Optional[str] = None
    target_port: Optional[int] = None
    target_service: Optional[str] = None
    
    # Tool configuration
    tool_name: str
    tool_command: str
    tool_options: Dict[str, Any] = Field(default_factory=dict)
    
    # Scoring (from Decision Engine)
    probability_success: float = Field(default=0.5, ge=0.0, le=1.0)
    impact_score: float = Field(default=5.0, ge=0.0, le=10.0)
    cost_score: float = Field(default=5.0, ge=0.0, le=10.0)
    risk_score: float = Field(default=5.0, ge=0.0, le=10.0)
    final_score: float = Field(default=0.0)
    
    # Execution
    status: ActionStatus = ActionStatus.PENDING
    executed_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    execution_time_ms: Optional[int] = None
    
    # Results
    output_raw: Optional[str] = None
    output_parsed: Optional[Dict[str, Any]] = None
    success: Optional[bool] = None
    error_message: Optional[str] = None
    
    # Metadata
    created_at: datetime = Field(default_factory=datetime.utcnow)
    depends_on: List[str] = Field(default_factory=list)  # Action IDs
    
    def calculate_score(self) -> float:
        """Calculate final score using MCDA formula"""
        if self.cost_score == 0 or self.risk_score == 0:
            return 0.0
        self.final_score = (
            (self.probability_success * self.impact_score) / 
            (self.cost_score * (1 + self.risk_score))
        )
        return self.final_score


class ActionPlan(BaseModel):
    """A plan containing multiple actions"""
    model_config = ConfigDict(frozen=False)
    
    id: str = Field(default_factory=lambda: str(uuid4()))
    name: str
    description: Optional[str] = None
    
    actions: List[Action] = Field(default_factory=list)
    current_action_index: int = Field(default=0, ge=0)
    
    # Status
    status: ActionStatus = ActionStatus.PENDING
    created_at: datetime = Field(default_factory=datetime.utcnow)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    
    def get_next_action(self) -> Optional[Action]:
        """Get the next action to execute"""
        if self.current_action_index < len(self.actions):
            return self.actions[self.current_action_index]
        return None
    
    def mark_action_complete(self, success: bool) -> None:
        """Mark current action as complete and advance"""
        if self.current_action_index < len(self.actions):
            self.actions[self.current_action_index].status = (
                ActionStatus.COMPLETED if success else ActionStatus.FAILED
            )
            self.current_action_index += 1


# ═══════════════════════════════════════════════════════════════════════════════
# Execution Result Models
# ═══════════════════════════════════════════════════════════════════════════════

class ToolOutput(BaseModel):
    """Structured output from a tool execution"""
    model_config = ConfigDict(frozen=False)
    
    tool_name: str
    command: str
    exit_code: int
    stdout: str
    stderr: str
    execution_time_ms: int
    
    # Parsed data
    parsed_data: Dict[str, Any] = Field(default_factory=dict)
    findings: List[Dict[str, Any]] = Field(default_factory=list)
    
    # Metadata
    executed_at: datetime = Field(default_factory=datetime.utcnow)
    sandbox_id: Optional[str] = None


class ExecutionResult(BaseModel):
    """Result of executing an action"""
    model_config = ConfigDict(frozen=False)
    
    action_id: str
    success: bool
    tool_output: Optional[ToolOutput] = None
    
    # Discovered entities
    new_hosts: List[Host] = Field(default_factory=list)
    new_ports: List[Port] = Field(default_factory=list)
    new_services: List[Service] = Field(default_factory=list)
    new_vulnerabilities: List[Vulnerability] = Field(default_factory=list)
    new_credentials: List[Credential] = Field(default_factory=list)
    
    # Analysis
    summary: Optional[str] = None
    recommendations: List[str] = Field(default_factory=list)
    next_actions: List[Action] = Field(default_factory=list)
    
    # Metadata
    executed_at: datetime = Field(default_factory=datetime.utcnow)


# ═══════════════════════════════════════════════════════════════════════════════
# Analysis Models
# ═══════════════════════════════════════════════════════════════════════════════

class AnalysisResult(BaseModel):
    """Result of analyzing execution output"""
    model_config = ConfigDict(frozen=False)
    
    execution_result_id: str
    
    # World Model updates
    hosts_updated: List[str] = Field(default_factory=list)
    hosts_added: List[str] = Field(default_factory=list)
    services_identified: List[str] = Field(default_factory=list)
    vulnerabilities_found: List[str] = Field(default_factory=list)
    
    # Assessment
    action_successful: bool
    confidence: float = Field(default=0.5, ge=0.0, le=1.0)
    
    # Insights
    key_findings: List[str] = Field(default_factory=list)
    attack_vectors: List[str] = Field(default_factory=list)
    
    # Learning
    pattern_identified: Optional[str] = None
    tactic_effectiveness: Optional[float] = None
    
    # Metadata
    analyzed_at: datetime = Field(default_factory=datetime.utcnow)


class LearningUpdate(BaseModel):
    """Update from learning agent"""
    model_config = ConfigDict(frozen=False)
    
    pattern_stored: bool = False
    pattern_id: Optional[str] = None
    
    tactic_scores_updated: List[str] = Field(default_factory=list)
    weights_adjusted: Dict[str, float] = Field(default_factory=dict)
    
    new_techniques_identified: List[str] = Field(default_factory=list)
    
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# ═══════════════════════════════════════════════════════════════════════════════
# State Models (for LangGraph)
# ═══════════════════════════════════════════════════════════════════════════════

class AgentState(BaseModel):
    """Main state for LangGraph"""
    model_config = ConfigDict(frozen=False)
    
    # Session info
    session_id: str = Field(default_factory=lambda: str(uuid4()))
    created_at: datetime = Field(default_factory=datetime.utcnow)
    iteration: int = Field(default=0, ge=0)
    
    # Configuration
    target_scope: List[str] = Field(default_factory=list)  # IP ranges, domains
    excluded_targets: List[str] = Field(default_factory=list)
    max_iterations: int = Field(default=100)
    
    # Current state
    current_phase: Phase = Phase.RECONNAISSANCE
    current_plan: Optional[ActionPlan] = None
    pending_actions: List[Action] = Field(default_factory=list)
    completed_actions: List[Action] = Field(default_factory=list)
    
    # World Model reference
    world_model_snapshot: Dict[str, Any] = Field(default_factory=dict)
    
    # Results
    execution_results: List[ExecutionResult] = Field(default_factory=list)
    analysis_results: List[AnalysisResult] = Field(default_factory=list)
    
    # Status
    goal_achieved: bool = False
    termination_reason: Optional[str] = None
    error_count: int = Field(default=0, ge=0)
    
    # Memory references
    relevant_memories: List[str] = Field(default_factory=list)
    
    def should_continue(self) -> bool:
        """Determine if the agent should continue"""
        if self.goal_achieved:
            return False
        if self.iteration >= self.max_iterations:
            return False
        if self.error_count > 10:
            return False
        return True


# ═══════════════════════════════════════════════════════════════════════════════
# Memory Models
# ═══════════════════════════════════════════════════════════════════════════════

class MemoryEntry(BaseModel):
    """Entry in long-term memory"""
    model_config = ConfigDict(frozen=False)
    
    id: str = Field(default_factory=lambda: str(uuid4()))
    content: str
    embedding: Optional[List[float]] = None
    
    # Context
    context_hash: str  # Hash of the situation where this was learned
    context_tags: List[str] = Field(default_factory=list)
    
    # Effectiveness tracking
    use_count: int = Field(default=0, ge=0)
    success_count: int = Field(default=0, ge=0)
    success_rate: float = Field(default=0.0, ge=0.0, le=1.0)
    
    # Metadata
    created_at: datetime = Field(default_factory=datetime.utcnow)
    last_used: Optional[datetime] = None


class TacticPattern(BaseModel):
    """Pattern of successful tactics"""
    model_config = ConfigDict(frozen=False)
    
    id: str = Field(default_factory=lambda: str(uuid4()))
    name: str
    description: Optional[str] = None
    
    # Pattern definition
    action_type: ActionType
    tool_name: str
    tool_options_pattern: Dict[str, Any] = Field(default_factory=dict)
    target_service_pattern: Optional[str] = None
    target_os_pattern: Optional[str] = None
    
    # Performance
    total_attempts: int = Field(default=0, ge=0)
    successful_attempts: int = Field(default=0, ge=0)
    avg_execution_time: Optional[float] = None
    success_rate: float = Field(default=0.0, ge=0.0, le=1.0)
    
    # Metadata
    created_at: datetime = Field(default_factory=datetime.utcnow)
    last_used: Optional[datetime] = None


# ═══════════════════════════════════════════════════════════════════════════════
# Report Models
# ═══════════════════════════════════════════════════════════════════════════════

class AttackPath(BaseModel):
    """Represents a discovered attack path"""
    model_config = ConfigDict(frozen=False)
    
    id: str = Field(default_factory=lambda: str(uuid4()))
    name: str
    description: Optional[str] = None
    
    # Path steps
    entry_point: str  # Host ID
    steps: List[Dict[str, Any]] = Field(default_factory=list)
    
    # Impact
    compromised_hosts: List[str] = Field(default_factory=list)
    accessed_data: List[str] = Field(default_factory=list)
    
    # Metadata
    discovered_at: datetime = Field(default_factory=datetime.utcnow)


class EngagementReport(BaseModel):
    """Final report of the engagement"""
    model_config = ConfigDict(frozen=False)
    
    session_id: str
    started_at: datetime
    completed_at: datetime = Field(default_factory=datetime.utcnow)
    
    # Scope
    target_scope: List[str]
    excluded_targets: List[str]
    
    # Summary
    total_iterations: int
    total_actions: int
    successful_actions: int
    failed_actions: int
    
    # Findings
    hosts_discovered: List[Host]
    services_identified: List[Service]
    vulnerabilities_found: List[Vulnerability]
    credentials_compromised: List[Credential]
    attack_paths: List[AttackPath]
    
    # Executive summary
    executive_summary: str
    risk_rating: str
    key_recommendations: List[str]
    
    # Technical details
    detailed_findings: List[Dict[str, Any]] = Field(default_factory=list)
    timeline: List[Dict[str, Any]] = Field(default_factory=list)


# ═══════════════════════════════════════════════════════════════════════════════
# Configuration Models
# ═══════════════════════════════════════════════════════════════════════════════

class LLMConfig(BaseModel):
    """Configuration for LLM connection"""
    model_config = ConfigDict(frozen=False)
    
    provider: str = "ollama"  # Only ollama supported for local
    base_url: str = "http://localhost:11434"
    model: str = "qwen2.5-coder:32b"
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    max_tokens: int = Field(default=4096, ge=1)
    timeout: int = Field(default=300, ge=1)
    
    # Embedding model
    embedding_model: str = "nomic-embed-text"


class DockerConfig(BaseModel):
    """Configuration for Docker sandbox"""
    model_config = ConfigDict(frozen=False)
    
    image: str = "kalilinux/kali-rolling:latest"
    network_mode: str = "bridge"
    
    # Resource limits
    cpu_limit: float = Field(default=2.0, ge=0.1)
    memory_limit: str = "4g"
    
    # Volumes
    tools_path: str = "./tools"
    workspace_path: str = "./workspace"
    
    # Capabilities
    capabilities: List[str] = Field(default_factory=lambda: ["NET_ADMIN"])
    
    # Snapshot settings
    enable_snapshots: bool = True
    snapshot_interval: int = 10  # Actions between snapshots


class DatabaseConfig(BaseModel):
    """Configuration for databases"""
    model_config = ConfigDict(frozen=False)
    
    # SQLite
    sqlite_path: str = "./data/redteam.db"
    
    # Vector store
    vector_store_type: str = "chroma"  # chroma or lancedb
    vector_store_path: str = "./data/vectors"
    
    # CVE/Exploit DB
    cve_db_path: str = "./data/cve.db"
    exploit_db_path: str = "./data/exploitdb"


class AgentConfig(BaseModel):
    """Main configuration for the agent"""
    model_config = ConfigDict(frozen=False)
    
    # Sub-configs
    llm: LLMConfig = Field(default_factory=LLMConfig)
    docker: DockerConfig = Field(default_factory=DockerConfig)
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    
    # Agent behavior
    max_iterations: int = Field(default=100, ge=1)
    parallel_actions: int = Field(default=1, ge=1)
    
    # Decision engine
    enable_monte_carlo: bool = True
    monte_carlo_iterations: int = Field(default=100, ge=10)
    
    # Logging
    log_level: str = "INFO"
    log_file: Optional[str] = "./logs/redteam.log"
    
    # Safety
    require_confirmation: bool = False  # For dangerous actions
    dry_run: bool = False  # Don't actually execute tools


# Export all models
__all__ = [
    # Enums
    "HostStatus", "PortState", "ServiceProtocol", "VulnerabilitySeverity",
    "ExploitType", "ExploitStatus", "ActionType", "ActionStatus", "Phase",
    
    # Network models
    "Port", "Service", "Vulnerability", "Exploit", "Credential", "Host", "NetworkSegment",
    
    # Action models
    "Action", "ActionPlan",
    
    # Execution models
    "ToolOutput", "ExecutionResult",
    
    # Analysis models
    "AnalysisResult", "LearningUpdate",
    
    # State models
    "AgentState",
    
    # Memory models
    "MemoryEntry", "TacticPattern",
    
    # Report models
    "AttackPath", "EngagementReport",
    
    # Config models
    "LLMConfig", "DockerConfig", "DatabaseConfig", "AgentConfig",
]
