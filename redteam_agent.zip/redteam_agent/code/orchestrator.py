"""
LangGraph Orchestrator - StateGraph with conditional edges for Red Team Agent
Implements the core feedback loop: Planner → Decision → Executor → Analyzer → Learner
"""

from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Literal, Optional, TypedDict

from langgraph.graph import END, StateGraph
from langgraph.graph.state import CompiledStateGraph
from langgraph.checkpoint.memory import MemorySaver

# Import our modules
from models import (
    Action,
    ActionPlan,
    ActionStatus,
    AgentConfig,
    AgentState,
    AnalysisResult,
    ExecutionResult,
    LearningUpdate,
    Phase,
)
from decision_engine import DecisionEngine
from docker_sandbox import DockerSandboxManager, SandboxConfig
from tool_layer import get_tool_registry

# Setup logging
logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════════
# State Definition for LangGraph
# ═══════════════════════════════════════════════════════════════════════════════

class GraphState(TypedDict):
    """State schema for LangGraph"""
    
    # Core state
    agent_state: AgentState
    
    # Current action tracking
    current_action: Optional[Action]
    current_plan: Optional[ActionPlan]
    
    # Results
    last_execution_result: Optional[ExecutionResult]
    last_analysis_result: Optional[AnalysisResult]
    last_learning_update: Optional[LearningUpdate]
    
    # Control flow
    should_continue: bool
    next_node: str
    error_message: Optional[str]


# ═══════════════════════════════════════════════════════════════════════════════
# Node Functions
# ═══════════════════════════════════════════════════════════════════════════════

class PlannerNode:
    """Planner Agent - Generates candidate actions based on current state"""
    
    def __init__(self, llm_client: Any, world_model: Any, memory: Any):
        self.llm = llm_client
        self.world_model = world_model
        self.memory = memory
    
    def __call__(self, state: GraphState) -> GraphState:
        """Generate action plan"""
        logger.info("=== PLANNER NODE ===")
        
        agent_state = state["agent_state"]
        
        try:
            # Get current world state
            world_snapshot = self.world_model.get_snapshot()
            
            # Query memory for similar past situations
            context_hash = self._hash_context(world_snapshot)
            relevant_memories = self.memory.get_relevant_memories(context_hash)
            
            # Generate candidate actions using LLM
            candidate_actions = self._generate_actions(
                agent_state=agent_state,
                world_snapshot=world_snapshot,
                memories=relevant_memories
            )
            
            # Create action plan
            plan = ActionPlan(
                name=f"plan_{agent_state.iteration}",
                description=f"Iteration {agent_state.iteration} plan",
                actions=candidate_actions,
            )
            
            # Update state
            state["current_plan"] = plan
            state["agent_state"].current_plan = plan
            state["agent_state"].pending_actions = candidate_actions
            state["next_node"] = "decision"
            state["error_message"] = None
            
            logger.info(f"Generated {len(candidate_actions)} candidate actions")
            
        except Exception as e:
            logger.error(f"Planner error: {e}")
            state["error_message"] = str(e)
            state["next_node"] = "error_handler"
        
        return state
    
    def _hash_context(self, world_snapshot: Dict) -> str:
        """Create hash of current context for memory lookup"""
        import hashlib
        snapshot_str = json.dumps(world_snapshot, sort_keys=True)
        return hashlib.sha256(snapshot_str.encode()).hexdigest()[:16]
    
    def _generate_actions(
        self,
        agent_state: AgentState,
        world_snapshot: Dict,
        memories: List[Dict]
    ) -> List[Action]:
        """Generate candidate actions using LLM and heuristics"""
        actions = []
        
        # Get discovered hosts and services
        hosts = world_snapshot.get("hosts", [])
        
        # Phase-specific action generation
        if agent_state.current_phase == Phase.RECONNAISSANCE:
            actions.extend(self._generate_recon_actions(hosts, agent_state))
        elif agent_state.current_phase == Phase.EXPLOITATION:
            actions.extend(self._generate_exploit_actions(hosts, world_snapshot))
        elif agent_state.current_phase == Phase.POST_EXPLOITATION:
            actions.extend(self._generate_post_exploit_actions(hosts, world_snapshot))
        
        # Add actions from memory (successful past patterns)
        for memory in memories:
            if memory.get("success_rate", 0) > 0.7:
                action = self._action_from_memory(memory)
                if action:
                    actions.append(action)
        
        return actions
    
    def _generate_recon_actions(
        self,
        hosts: List[Dict],
        agent_state: AgentState
    ) -> List[Action]:
        """Generate reconnaissance actions"""
        actions = []
        
        # If no hosts discovered yet, do network discovery
        if not hosts:
            for target in agent_state.target_scope:
                actions.append(Action(
                    name=f"nmap_host_discovery_{target}",
                    action_type="recon",
                    tool_name="nmap",
                    tool_command=f"nmap -sn -PE -PP -PM {target}",
                    phase=Phase.RECONNAISSANCE,
                    probability_success=0.9,
                    impact_score=5.0,
                    cost_score=2.0,
                    risk_score=1.0,
                ))
        else:
            # Port scan discovered hosts
            for host in hosts:
                ip = host.get("ip")
                if ip and not host.get("ports"):
                    actions.append(Action(
                        name=f"nmap_port_scan_{ip}",
                        action_type="scan",
                        tool_name="nmap",
                        tool_command=f"nmap -sV -sC -O --top-ports 1000 {ip}",
                        phase=Phase.RECONNAISSANCE,
                        target_host_id=host.get("id"),
                        probability_success=0.95,
                        impact_score=7.0,
                        cost_score=5.0,
                        risk_score=2.0,
                    ))
        
        return actions
    
    def _generate_exploit_actions(
        self,
        hosts: List[Dict],
        world_snapshot: Dict
    ) -> List[Action]:
        """Generate exploitation actions based on discovered services"""
        actions = []
        
        for host in hosts:
            ip = host.get("ip")
            services = host.get("services", {})
            
            for svc_key, service in services.items():
                svc_name = service.get("name", "").lower()
                
                # Web services
                if svc_name in ["http", "https"]:
                    actions.append(Action(
                        name=f"gobuster_dirs_{ip}_{svc_key}",
                        action_type="enumerate",
                        tool_name="gobuster",
                        tool_command=f"gobuster dir -u http://{ip} -w /usr/share/wordlists/dirb/common.txt",
                        phase=Phase.EXPLOITATION,
                        target_host_id=host.get("id"),
                        probability_success=0.6,
                        impact_score=6.0,
                        cost_score=3.0,
                        risk_score=1.0,
                    ))
                
                # SSH
                if svc_name == "ssh":
                    actions.append(Action(
                        name=f"hydra_ssh_{ip}",
                        action_type="credential_attack",
                        tool_name="hydra",
                        tool_command=f"hydra -l admin -P /usr/share/wordlists/rockyou.txt ssh://{ip}",
                        phase=Phase.EXPLOITATION,
                        target_host_id=host.get("id"),
                        target_port=22,
                        probability_success=0.2,
                        impact_score=9.0,
                        cost_score=8.0,
                        risk_score=5.0,
                    ))
        
        return actions
    
    def _generate_post_exploit_actions(
        self,
        hosts: List[Dict],
        world_snapshot: Dict
    ) -> List[Action]:
        """Generate post-exploitation actions"""
        actions = []
        
        compromised_hosts = [h for h in hosts if h.get("compromised")]
        
        for host in compromised_hosts:
            ip = host.get("ip")
            actions.append(Action(
                name=f"enumerate_users_{ip}",
                action_type="post_exploit",
                tool_name="meterpreter",
                tool_command=f"run post/linux/gather/enum_users",
                phase=Phase.POST_EXPLOITATION,
                target_host_id=host.get("id"),
                probability_success=0.7,
                impact_score=8.0,
                cost_score=3.0,
                risk_score=3.0,
            ))
        
        return actions
    
    def _action_from_memory(self, memory: Dict) -> Optional[Action]:
        """Reconstruct action from memory entry"""
        try:
            return Action(
                name=memory.get("name", "memory_action"),
                action_type=memory.get("action_type", "scan"),
                tool_name=memory.get("tool_name", "nmap"),
                tool_command=memory.get("tool_command", ""),
                phase=Phase(memory.get("phase", "reconnaissance")),
                probability_success=memory.get("success_rate", 0.5),
                impact_score=memory.get("impact_score", 5.0),
                cost_score=memory.get("cost_score", 5.0),
                risk_score=memory.get("risk_score", 2.0),
            )
        except Exception:
            return None


class DecisionNode:
    """Decision Engine Node - Selects best action using MCDA"""
    
    def __init__(self, decision_engine: DecisionEngine):
        self.engine = decision_engine
    
    def __call__(self, state: GraphState) -> GraphState:
        """Select best action from candidates"""
        logger.info("=== DECISION NODE ===")
        
        plan = state.get("current_plan")
        if not plan or not plan.actions:
            logger.warning("No actions to evaluate")
            state["next_node"] = "planner"
            return state
        
        try:
            # Filter pending actions
            pending = [a for a in plan.actions if a.status == ActionStatus.PENDING]
            
            if not pending:
                logger.info("All actions completed, moving to next phase")
                state = self._advance_phase(state)
                state["next_node"] = "planner"
                return state
            
            # Use decision engine to select best action
            best_action, rankings = self.engine.select_best_action(
                actions=pending,
                context={"phase": state["agent_state"].current_phase},
                top_k=3
            )
            
            # Update state
            state["current_action"] = best_action
            best_action.status = ActionStatus.RUNNING
            best_action.executed_at = datetime.utcnow()
            
            logger.info(f"Selected action: {best_action.name} (score: {best_action.final_score:.4f})")
            logger.info(f"Top 3 rankings: {[r['action_name'] for r in rankings]}")
            
            state["next_node"] = "executor"
            state["error_message"] = None
            
        except Exception as e:
            logger.error(f"Decision error: {e}")
            state["error_message"] = str(e)
            state["next_node"] = "error_handler"
        
        return state
    
    def _advance_phase(self, state: GraphState) -> GraphState:
        """Advance to next attack phase"""
        phase_order = [
            Phase.RECONNAISSANCE,
            Phase.WEAPONIZATION,
            Phase.DELIVERY,
            Phase.EXPLOITATION,
            Phase.INSTALLATION,
            Phase.COMMAND_CONTROL,
            Phase.ACTIONS_ON_OBJECTIVES,
        ]
        
        current = state["agent_state"].current_phase
        if current in phase_order:
            idx = phase_order.index(current)
            if idx < len(phase_order) - 1:
                state["agent_state"].current_phase = phase_order[idx + 1]
                logger.info(f"Advanced to phase: {state['agent_state'].current_phase}")
        
        return state


class ExecutorNode:
    """Executor Agent - Executes selected action in Docker sandbox"""
    
    def __init__(
        self,
        sandbox_manager: DockerSandboxManager,
        tool_registry: Any
    ):
        self.sandbox = sandbox_manager
        self.tools = tool_registry
    
    def __call__(self, state: GraphState) -> GraphState:
        """Execute the selected action"""
        logger.info("=== EXECUTOR NODE ===")
        
        action = state.get("current_action")
        if not action:
            logger.error("No action to execute")
            state["next_node"] = "decision"
            return state
        
        try:
            # Get or create container
            container_id = self._get_or_create_container(state)
            
            # Execute tool
            logger.info(f"Executing: {action.tool_name} {action.tool_command}")
            
            tool_output = self.sandbox.execute_tool(
                container_id=container_id,
                tool_name=action.tool_name,
                tool_args=action.tool_command.replace(f"{action.tool_name} ", ""),
                timeout=300,
            )
            
            # Create execution result
            execution_result = ExecutionResult(
                action_id=action.id,
                success=tool_output.exit_code == 0,
                tool_output=tool_output,
            )
            
            # Parse tool output
            parsed = self.tools.process(action.tool_name, tool_output)
            
            # Add discovered entities
            execution_result.new_hosts = parsed.get("hosts", [])
            execution_result.new_ports = parsed.get("ports", [])
            execution_result.new_services = parsed.get("services", [])
            execution_result.new_vulnerabilities = parsed.get("vulnerabilities", [])
            execution_result.new_credentials = parsed.get("credentials", [])
            
            # Update state
            state["last_execution_result"] = execution_result
            state["agent_state"].execution_results.append(execution_result)
            
            action.status = ActionStatus.COMPLETED if execution_result.success else ActionStatus.FAILED
            action.completed_at = datetime.utcnow()
            action.output_raw = tool_output.stdout
            action.success = execution_result.success
            
            logger.info(f"Execution completed: success={execution_result.success}")
            logger.info(f"Discovered: {len(execution_result.new_hosts)} hosts, "
                       f"{len(execution_result.new_ports)} ports, "
                       f"{len(execution_result.new_vulnerabilities)} vulns")
            
            state["next_node"] = "analyzer"
            state["error_message"] = None
            
        except Exception as e:
            logger.error(f"Execution error: {e}")
            action.status = ActionStatus.FAILED
            action.error_message = str(e)
            state["error_message"] = str(e)
            state["next_node"] = "error_handler"
        
        return state
    
    def _get_or_create_container(self, state: GraphState) -> str:
        """Get existing container or create new one"""
        # Check if we have a running container
        containers = self.sandbox.list_containers(all_containers=False)
        
        if containers:
            return containers[0]["id"]
        
        # Create new container
        container_id = self.sandbox.create_container()
        self.sandbox.start_container(container_id)
        
        return container_id


class AnalyzerNode:
    """Analyzer Agent - Analyzes execution results and updates World Model"""
    
    def __init__(self, world_model: Any, llm_client: Any):
        self.world_model = world_model
        self.llm = llm_client
    
    def __call__(self, state: GraphState) -> GraphState:
        """Analyze execution results"""
        logger.info("=== ANALYZER NODE ===")
        
        execution_result = state.get("last_execution_result")
        if not execution_result:
            logger.warning("No execution result to analyze")
            state["next_node"] = "learner"
            return state
        
        try:
            # Update World Model with discovered entities
            hosts_added = []
            services_identified = []
            vulnerabilities_found = []
            
            # Add new hosts
            for host in execution_result.new_hosts:
                host_id = self.world_model.add_host(host)
                if host_id:
                    hosts_added.append(host_id)
            
            # Add ports and services
            for port in execution_result.new_ports:
                self.world_model.add_port(port)
            
            for service in execution_result.new_services:
                svc_id = self.world_model.add_service(service)
                services_identified.append(svc_id)
            
            # Add vulnerabilities
            for vuln in execution_result.new_vulnerabilities:
                vuln_id = self.world_model.add_vulnerability(vuln)
                vulnerabilities_found.append(vuln_id)
            
            # Analyze success/failure
            action_successful = execution_result.success and (
                len(execution_result.new_hosts) > 0 or
                len(execution_result.new_ports) > 0 or
                len(execution_result.new_vulnerabilities) > 0
            )
            
            # Generate key findings
            key_findings = self._generate_findings(execution_result)
            
            # Create analysis result
            analysis_result = AnalysisResult(
                execution_result_id=execution_result.action_id,
                hosts_added=hosts_added,
                services_identified=services_identified,
                vulnerabilities_found=vulnerabilities_found,
                action_successful=action_successful,
                confidence=0.8 if action_successful else 0.3,
                key_findings=key_findings,
            )
            
            # Update state
            state["last_analysis_result"] = analysis_result
            state["agent_state"].analysis_results.append(analysis_result)
            
            logger.info(f"Analysis complete: {len(hosts_added)} hosts, "
                       f"{len(vulnerabilities_found)} vulns, "
                       f"success={action_successful}")
            
            state["next_node"] = "learner"
            state["error_message"] = None
            
        except Exception as e:
            logger.error(f"Analysis error: {e}")
            state["error_message"] = str(e)
            state["next_node"] = "error_handler"
        
        return state
    
    def _generate_findings(self, execution_result: ExecutionResult) -> List[str]:
        """Generate human-readable findings"""
        findings = []
        
        if execution_result.new_hosts:
            findings.append(f"Discovered {len(execution_result.new_hosts)} new host(s)")
        
        if execution_result.new_vulnerabilities:
            crit_count = sum(1 for v in execution_result.new_vulnerabilities 
                           if v.severity.value == "critical")
            if crit_count > 0:
                findings.append(f"Found {crit_count} CRITICAL vulnerability(ies)!")
        
        if execution_result.new_credentials:
            findings.append(f"Compromised {len(execution_result.new_credentials)} credential(s)")
        
        return findings


class LearnerNode:
    """Learning Agent - Updates long-term memory with patterns"""
    
    def __init__(self, memory: Any, decision_engine: DecisionEngine):
        self.memory = memory
        self.decision_engine = decision_engine
    
    def __call__(self, state: GraphState) -> GraphState:
        """Learn from execution results"""
        logger.info("=== LEARNER NODE ===")
        
        execution_result = state.get("last_execution_result")
        analysis_result = state.get("last_analysis_result")
        action = state.get("current_action")
        
        if not execution_result or not action:
            logger.warning("Nothing to learn from")
            state["next_node"] = "should_continue"
            return state
        
        try:
            # Store successful pattern
            pattern_stored = False
            pattern_id = None
            
            if execution_result.success and analysis_result and analysis_result.action_successful:
                pattern_id = self.memory.store_pattern(
                    action=action,
                    context=state["agent_state"].world_model_snapshot,
                    result=execution_result
                )
                pattern_stored = True
                logger.info(f"Stored successful pattern: {pattern_id}")
            
            # Update tactic effectiveness
            tactic_scores = self.memory.update_tactic_score(
                tool_name=action.tool_name,
                success=execution_result.success
            )
            
            # Update decision engine weights based on outcome
            self.decision_engine.update_weights_from_outcome(
                action=action,
                success=execution_result.success
            )
            
            # Create learning update
            learning_update = LearningUpdate(
                pattern_stored=pattern_stored,
                pattern_id=pattern_id,
                tactic_scores_updated=tactic_scores,
            )
            
            state["last_learning_update"] = learning_update
            
            logger.info(f"Learning complete: pattern_stored={pattern_stored}")
            
            state["next_node"] = "should_continue"
            state["error_message"] = None
            
        except Exception as e:
            logger.error(f"Learning error: {e}")
            state["error_message"] = str(e)
            state["next_node"] = "should_continue"  # Continue even if learning fails
        
        return state


class ErrorHandlerNode:
    """Error Handler - Handles errors gracefully"""
    
    def __call__(self, state: GraphState) -> GraphState:
        """Handle errors"""
        logger.error(f"=== ERROR HANDLER: {state.get('error_message')} ===")
        
        # Increment error count
        state["agent_state"].error_count += 1
        
        # Decide whether to continue or terminate
        if state["agent_state"].error_count > 5:
            logger.error("Too many errors, terminating")
            state["should_continue"] = False
            state["agent_state"].termination_reason = "too_many_errors"
            state["next_node"] = END
        else:
            # Try to recover by going back to planner
            logger.info("Attempting recovery...")
            state["next_node"] = "planner"
        
        return state


# ═══════════════════════════════════════════════════════════════════════════════
# Conditional Edge Functions
# ═══════════════════════════════════════════════════════════════════════════════

def should_continue_edge(state: GraphState) -> str:
    """
    Determine if the agent should continue or terminate
    
    Returns:
        Next node name
    """
    agent_state = state["agent_state"]
    
    # Check termination conditions
    if agent_state.iteration >= agent_state.max_iterations:
        logger.info("Max iterations reached, terminating")
        agent_state.termination_reason = "max_iterations"
        return END
    
    if agent_state.goal_achieved:
        logger.info("Goal achieved, terminating")
        agent_state.termination_reason = "goal_achieved"
        return END
    
    # Check if we've discovered enough
    world_snapshot = state.get("agent_state", {}).world_model_snapshot
    if world_snapshot:
        hosts = world_snapshot.get("hosts", [])
        critical_vulns = sum(
            1 for h in hosts 
            for v in h.get("vulnerabilities", [])
            if v.get("severity") == "critical"
        )
        
        if critical_vulns > 0 and agent_state.iteration > 20:
            logger.info("Critical vulnerabilities found, can terminate")
            # Don't terminate automatically, let the user decide
    
    # Continue to next iteration
    agent_state.iteration += 1
    logger.info(f"Continuing to iteration {agent_state.iteration}")
    
    return "planner"


def route_from_error(state: GraphState) -> str:
    """Route from error handler"""
    if state.get("should_continue", True):
        return "planner"
    return END


# ═══════════════════════════════════════════════════════════════════════════════
# Graph Builder
# ═══════════════════════════════════════════════════════════════════════════════

def create_orchestrator(
    config: AgentConfig,
    llm_client: Any,
    world_model: Any,
    memory: Any,
    sandbox_manager: DockerSandboxManager,
) -> CompiledStateGraph:
    """
    Create and compile the LangGraph orchestrator
    
    Args:
        config: Agent configuration
        llm_client: LLM client for Ollama
        world_model: World Model instance
        memory: Memory system instance
        sandbox_manager: Docker sandbox manager
        
    Returns:
        Compiled StateGraph
    """
    # Initialize components
    decision_engine = DecisionEngine(
        enable_monte_carlo=config.enable_monte_carlo,
        mc_iterations=config.monte_carlo_iterations,
    )
    
    tool_registry = get_tool_registry()
    
    # Create nodes
    planner = PlannerNode(llm_client, world_model, memory)
    decision = DecisionNode(decision_engine)
    executor = ExecutorNode(sandbox_manager, tool_registry)
    analyzer = AnalyzerNode(world_model, llm_client)
    learner = LearnerNode(memory, decision_engine)
    error_handler = ErrorHandlerNode()
    
    # Build graph
    workflow = StateGraph(GraphState)
    
    # Add nodes
    workflow.add_node("planner", planner)
    workflow.add_node("decision", decision)
    workflow.add_node("executor", executor)
    workflow.add_node("analyzer", analyzer)
    workflow.add_node("learner", learner)
    workflow.add_node("error_handler", error_handler)
    
    # Add edges
    workflow.set_entry_point("planner")
    
    workflow.add_edge("planner", "decision")
    workflow.add_edge("decision", "executor")
    workflow.add_edge("executor", "analyzer")
    workflow.add_edge("analyzer", "learner")
    
    # Conditional edge from learner
    workflow.add_conditional_edges(
        "learner",
        should_continue_edge,
        {
            "planner": "planner",
            END: END,
        }
    )
    
    # Error handling
    workflow.add_conditional_edges(
        "error_handler",
        route_from_error,
        {
            "planner": "planner",
            END: END,
        }
    )
    
    # Add error edges from each node
    for node in ["planner", "decision", "executor", "analyzer"]:
        workflow.add_conditional_edges(
            node,
            lambda s, n=node: "error_handler" if s.get("error_message") else None,
            {"error_handler": "error_handler"}
        )
    
    # Compile with checkpointing
    checkpointer = MemorySaver()
    compiled = workflow.compile(checkpointer=checkpointer)
    
    logger.info("Orchestrator compiled successfully")
    
    return compiled


# Example usage
if __name__ == "__main__":
    # This is a simplified example - in production you'd initialize all components
    
    print("=== LangGraph Orchestrator ===")
    print("Graph structure:")
    print("  planner → decision → executor → analyzer → learner → [should_continue?]")
    print("                                    ↓")
    print("                              error_handler")
